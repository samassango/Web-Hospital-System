<?php 
	header("Content-type: application/vnd.ms-word");
	header("Content-Disposition: attachment;Filename=all_registered_cabs.doc");
?>
<!DOCTYPE HTML>
<html lang="en">
	<head>
	</head>
	
	<body>
    	 <h1 align="right">DOCTOR FINDER</h1>
         <h3 align="right">Booked Patient and Allocated Doctors</h3>
    	 <h3  align="left">Report generated on: <?php echo date("d M Y h:is a"); ?></h3>
         <table border="1" bordercolor="#333333" cellpadding="5" cellspacing="0" style="font-size: 10px;">
				<?php
                
                    include "conn.php" ;
                    
                    $select = "select * from book_patients_tb" ;
                    
                    $result = $dbconn->query( $select ) ;
                    
                    if ( $result->num_rows > 0 ) {
                        ?>
                            <table border="1" bordercolor="#333333" cellpadding="5" cellspacing="0" style="font-size: 10px;">
                                <tr bgcolor="#333333" style="color:#fff;">
                                    <th>Patient Id#</th>
                                    <th>Doctor Id#</th>
                                    <th>Date Booked</th>
                                    <th>Patient Illness</th>
                                    <th>Type of treatment</th>
                                    <th>Patient Release date</th>
                                </tr>
                        <?php
                        
                        for ( $i = 0; $i < $result->num_rows; $i++ ) {
                            $row = $result->fetch_assoc() ;
                            
                            $bp_code = $row["bp_code"] ; 
                            $p_id = $row["p_id"] ;
                            $d_id = $row["d_id"] ;
                            $date_booked = $row["date_booked"] ;
                            $descptive_illness = $row["descptive_illness"] ;
                            $type_of_treatment = $row["type_of_treatment"] ;
                            $reliv_date = $row["reliv_date"] ;
                            
                            ?>
                                <tr bgcolor="#ffffff">
                                    <th><?php echo $p_id ; ?></th>
                                    <th><?php echo $d_id ; ?></th>
                                    <th><?php echo $date_booked ; ?></th>
                                    <th><?php echo $descptive_illness ; ?></th>
                                    <th><?php echo $type_of_treatment ; ?></th>
                                    <th><?php echo $reliv_date ; ?></th>
                                </tr>                                            	
                            <?php

                        }
                        
                    } else {
                    
                        echo "<h1>No records found</h1>" ;	
                        
                    }
                    
                    
                ?>
         </table>
 	</body>
</html>