<?php
	session_start() ;
	include "conn.php" ;
	
	$status=$_GET["status"] ; 

	
	$insert = "update book_patients_tb set request_status = 'Approved' where bp_code = '$status'" ;
	
	$result = $dbconn->query( $insert ) ;
	
	if ( $dbconn->affected_rows > 0 ) echo "success" ;
	else echo "Unable to update this patient status; Please try again later." ;
	
	// Function to generate id for table or function data needs a unique identifier.
	function generateUniqueIdentifier( $start_str, $table_name ) {
   	   include "conn.php" ;
	   $str = "select * from $table_name";
	   $rst = $dbconn->query( $str );
	   $num = $rst->num_rows; 
	     
	   if ( $num < 10 ) 
		  $start_str .= "000000".( $num+1 );
	   else if ( $num < 100 ) 
		  $start_str .= "00000".( $num+1 );
	   else if ( $num < 1000 ) 
		  $start_str .= "0000".( $num+1 );
	   else if ( $num < 10000 ) 
		  $start_str .= "000".( $num+1 );
	   else if ( $num < 100000 ) 
		  $start_str .= "00".( $num+1 );
	   else if ( $num < 1000000 ) 
		  $start_str .= "0".( $num+1 );
	   else
		  $start_str .= ( $num+1 );
	   return $start_str;  		
	}	
?>