<?php

	include "conn.php" ;
	  
    $name=$_GET["name"]; 
    $cell=$_GET["cell"];
    $email=$_GET["email"];
    $acode=$_GET["acode"];
    $hospital=$_GET["hospital"];
	$idno = $_GET["idno"];
	
	$insert = "insert into admins_tb values('$idno','$name','$email','$cell','$hospital','$acode')" ;
	
	$result = $dbconn->query( $insert ) ;
	
	if ( $dbconn->affected_rows > 0 ) {
		echo "success" ;
	} else {
		echo "Sorry we have a problem connecting to the server." ;	
	}
	
?>