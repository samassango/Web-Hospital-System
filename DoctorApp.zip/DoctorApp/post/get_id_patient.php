<?php
	
	include "conn.php" ;
	
	$name = $_GET["name"] ; 
	
	$select = "select * from patients_tb where names like '$name%'" ;
	
	$result = $dbconn->query( $select ) ;
	echo "<table>" ;
	if ( $result->num_rows > 0 ) {
		for ( $i = 0; $i < $result->num_rows; $i++ ) {
			$rows = $result->fetch_assoc() ;
			
			$names = $rows["names"] ;
			$surnames = $rows["surnames"] ;
			$idnos = $rows["idnos"] ;
			
			// idnos 	names 	surnames 	houses 	streets 	postals 	payments 	medicals 	illnesses 	priorty
			echo "<tr><td><a href='#' onclick=\"getID('$idnos')\" >$surnames $names</a></td><td>$idnos</td></tr>" ;
		}
	} else {
		echo "no results." ;	
	}
	echo "<table>" ;
?>