<?php
	session_start() ;
	include "conn.php" ;
	
	$idnos = $_SESSION["idnos"] ;
	$pid=$_GET["p_id"] ; 
	$hid=$_GET["h_id"] ;
	$fid="" ;
	$td="" ;
	$fcode=$_GET["p_fac_code"];

	$select = "select * from patients_tb where idnos = '$pid'" ;
	
	$result = $dbconn->query( $select ) ;
	if ( $result->num_rows > 0 ) {

		$rows = $result->fetch_assoc() ;
		
		$fid = $rows["illnesses"] ;
		$td = $rows["medicals"] ;
		
	} else {

		$fid="not set" ;
		$td="not set" ;
	
	}

	$days="0" ;
	
	$dates = date( "Y-m-d H:i:s" ) ;
	
	$end_date = date( 'Y-m-d H:i:s',strtotime($dates ." + $days days"));
	
	
	
	$id = generateUniqueIdentifier( "BKN", "book_patients_tb" ) ; 
	
	$insert = "insert into book_patients_tb values('$id','$pid','$idnos','$hid','$fcode','$dates','$fid','$td','$end_date','active','Pending')" ;
	
	$result = $dbconn->query( $insert ) ;
	
	if ( $dbconn->affected_rows > 0 ) echo "success" ;
	else echo "Unable to book this patient; Please try again later." ;
	
	// Function to generate id for table or function data needs a unique identifier.
	function generateUniqueIdentifier( $start_str, $table_name ) {
   	   include "conn.php" ;
	   $str = "select * from $table_name";
	   $rst = $dbconn->query( $str );
	   $num = $rst->num_rows; 
	     
	   if ( $num < 10 ) 
		  $start_str .= "000000".( $num+1 );
	   else if ( $num < 100 ) 
		  $start_str .= "00000".( $num+1 );
	   else if ( $num < 1000 ) 
		  $start_str .= "0000".( $num+1 );
	   else if ( $num < 10000 ) 
		  $start_str .= "000".( $num+1 );
	   else if ( $num < 100000 ) 
		  $start_str .= "00".( $num+1 );
	   else if ( $num < 1000000 ) 
		  $start_str .= "0".( $num+1 );
	   else
		  $start_str .= ( $num+1 );
	   return $start_str;  		
	}	
?>