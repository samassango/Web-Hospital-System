<?php 
	header("Content-type: application/vnd.ms-word");
	header("Content-Disposition: attachment;Filename=all_registered_cabs.doc");
?>
<!DOCTYPE HTML>
<html lang="en">
	<head>
	</head>
	
	<body>
    	 <h1 align="right">DOCTOR FINDER</h1>
         <h3 align="right">Doctors</h3>
    	 <h3  align="left">Report generated on: <?php echo date("d M Y h:is a"); ?></h3>
         <table border="1" bordercolor="#333333" cellpadding="5" cellspacing="0" style="font-size: 10px;">
			<?php
            
                include "conn.php" ;
                
                $select = "select * from doctors_tb" ;
                
                $result = $dbconn->query( $select ) ;
                
                if ( $result->num_rows > 0 ) {
                    ?>
                        <table border="1" bordercolor="#333333" cellpadding="5" cellspacing="0" style="font-size: 10px;">
                            <tr bgcolor="#333333" style="color:#fff;">
                                <th>Doctor name</th>
                                <th>Doctor cell</th>
                                <th>Doctor email</th>
                                <th>Doctor hospital</th>
                                <th>Doctor location</th>
                                <th>Doctor Specialty</th>
                            </tr>
                    <?php
                    
                    for ( $i = 0; $i < $result->num_rows; $i++ ) {
                        $row = $result->fetch_assoc() ;
                        
                        $p_id = $row["names"] ;
                        $d_id = $row["cells"] ;
                        $date_booked = $row["emails"] ;
                        $descptive_illness = $row["hospitals"] ;
                        $type_of_treatment = $row["locations"] ;
                        $reliv_date = $row["specials"] ;
                        
                        ?>
                            <tr bgcolor="#ffffff">
                                <th><?php echo $p_id ; ?></th>
                                <th><?php echo $d_id ; ?></th>
                                <th><?php echo $date_booked ; ?></th>
                                <th><?php echo $descptive_illness ; ?></th>
                                <th><?php echo $type_of_treatment ; ?></th>
                                <th><?php echo $reliv_date ; ?></th>
                            </tr>                                            	
                        <?php

                    }
                    
                } else {
                
                    echo "<h1>No records found</h1>" ;	
                    
                }
                
                
            ?>
         </table>
 	</body>
</html>