<?php
	include "conn.php" ;

	$name = $_GET["name"] ;
	$idno = $_GET["idno"] ;
	$email = $_GET["email"] ;
	$prno = $_GET["prno"] ;
	$special = $_GET["special"] ;
	$cell = $_GET["cell"] ;
	$hospital = $_GET["hospital"] ;
	$location = $_GET["location"] ;
	
	$insert = "insert into doctors_tb values('$idno','$name','$cell','$email','$hospital','$location','$special','$prno')" ;
	
	$result = $dbconn->query( $insert ) ;
	
	if ( $dbconn->affected_rows > 0 ) {
		echo "success" ;
	} else {
		echo "Sorry we have a problem connecting to the server." ;	
	}

?>