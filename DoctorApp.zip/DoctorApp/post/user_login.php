<?php

	session_start() ;

	include "conn.php" ;
	
	$uname=$_GET["uname"] ;
	$pword=$_GET["pword"] ;
	
	$select = "select * from logins_tb where unames = '$uname' and pwords = '$pword'" ;
	
	$result = $dbconn->query( $select ) ;
	
	if ( $result->num_rows > 0 ) {
		
		$rows = $result->fetch_assoc() ;
		
		$_SESSION["idnos"] = $rows["idnos"] ;
		$_SESSION["utypes"] = $rows["utypes"] ;
		
		echo $rows["utypes"] ;
		
	} else {
		
		echo "Sorry unable to log you in username or password is incorrect." ;	
		
	}
	
?>