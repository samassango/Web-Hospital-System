<?php
	include "conn.php" ;
	
	$uname=$_GET["uname"] ;
	$pword=$_GET["pword"] ;
	$utype=$_GET["utype"] ;
	$idno=$_GET["idno"] ;
	
	$insert = "insert into logins_tb values('$uname','$pword','$utype','$idno')" ;
	
	$result = $dbconn->query( $insert ) ;
	
	if ( $dbconn->affected_rows > 0 ) {
		echo $utype ;
	} else {
		echo "Sorry we have a problem connecting to the server." ;	
	}
?>
