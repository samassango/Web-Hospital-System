<?php
 session_start();
 include "fpdf.php";
 include "conn.php";

class PDF extends FPDF
{ 
	// Load data
	function readData() {
		// Read file lines
	   include "conn.php";
	   $str = "select * from book_patients_tb";
	   $rst = $dbconn->query( $str );
	   $num = $rst->num_rows;
      for ( $i = 0; $i < $num; $i++ ) {
         $rows = $rst->fetch_assoc();
	     $str = $rows['p_id'].";".$rows['d_id']. ";" .$rows['date_booked'].";".$rows['descptive_illness'].";".
		 		$rows['type_of_treatment'].";".$rows['reliv_date']."\n";

	     @ $fp = fopen( "Patient.txt", 'a' );
	     if ( !$fp ) {
			// Title
			$this->Cell(0,0,'Could not write the file',0,0,'R');
			// Line break
			$this->Ln(5);
		 } else {
	        fwrite( $fp, $str, strlen( $str ) );
	        fclose( $fp ); 
	     }		 
	    } 
	}
   // Load data
   function LoadData($file) {
       // Read file lines
       $lines = file($file);
       $data = array();
       foreach($lines as $line)
           $data[] = explode(';',trim($line));
        return $data;
    }
	// Page header
	function Header() {
		$this->SetFont('Arial','B',18);
		// Move to the right
		$this->Cell(160);
		// Title
		$this->Cell(30,10,"DOCTOR FINDER",0,0,'R') ;
		
		$this->SetFont('Arial','B',12);
		$this->Ln(10);
		$this->Cell(80,10,"Booked Patient and Allocated Doctors",0,0,'R') ;

		// Line break
		$this->Ln(10);
		$this->Cell(30);
		$this->SetFont('Arial','',9);
		$this->Cell(40,5,"Report generated on: " . date("d M Y h:i:s a"),0,0,'R');
		$this->Ln(10);
        //================================================================//
	}
	function ImprovedTable($header, $data)
	{  
		// Column widths
		$w = array(30,30,30,30,30,35);
		// Header
		for($i=0;$i<count($header);$i++)
			$this->Cell($w[$i],7,$header[$i],1,0,'C');
		$this->Ln();
		// Data
		foreach($data as $row)
		{
			$this->Cell($w[0],6,$row[0],'LR');
			$this->Cell($w[1],6,$row[1],'LR');
			$this->Cell($w[2],6,$row[2],'LR');
			$this->Cell($w[3],6,$row[3],'LR');
			$this->Cell($w[4],6,$row[4],'LR');
			$this->Cell($w[5],6,$row[5],'LR');
			$this->Ln();
		}
		// Closing line
		$this->Cell(array_sum($w),0,'','T');
	}

	
	// Page footer
	function Footer() {
		// Position at 1.5 cm from bottom
		$this->SetY(-15);
		// Arial italic 8
		$this->SetFont('Arial','I',8);
		// Page number
		$this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
	}
}

// Instanciation of inherited class
$pdf = new PDF();
// Column headings
$header = array( "Patient Id#","Doctor Id#","Date Booked","Patient Illness","Type of treatment","Patient Release date" );
$pdf->readData();
$data = $pdf->LoadData( 'Patient.txt' );
$pdf->AliasNbPages();
$pdf->SetSubject("All Registered Doctors", true);
$pdf->SetFont('Arial','',8);
$pdf->AddPage();
$pdf->ImprovedTable($header,$data);
$pdf->Output();
unlink("Patient.txt");
?>