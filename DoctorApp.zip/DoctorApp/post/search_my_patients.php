<?php
	session_start() ;
	include "conn.php" ;
	
	$idnos = $_SESSION["idnos"] ;
	$search=$_GET["search"] ;
	
	$select = "select * from book_patients_tb where d_id = '$idnos' and p_id = '$search'" ;
	
	$result = $dbconn->query( $select ) ;
	
	if ( $result->num_rows > 0 ) {
		
		$rows = $result->fetch_assoc() ;
		
		$p_id = $rows["p_id"] ;
		$date_booked = $rows["date_booked"] ;
		$descptive_illness = $rows["descptive_illness"] ;
		$type_of_treatment = $rows["type_of_treatment"] ;
		$reliv_date = $rows["reliv_date"] ;
		$record_status = $rows["record_status"] ;
		
		$dates = date( "Y-m-d H:i:s" ) ;
		echo "<h1 align='center'>DOCTOR FINDER</h1><br />" ;
		echo "<h3 align='center'>Patient report</h3>" ;
		echo "<p align='right'>Generated on : $dates</p>" ;
		
		echo "<br /><br /><br /><br />
				<table>
				<tr><td><strong>Patient ID</strong></td><td>: $p_id</td></tr>
				<tr><td><strong>Admission Date</strong></td><td>: $date_booked</td></tr>
				<tr><td><strong>Relieve Date</strong></td><td>: $reliv_date</td></tr>
				<tr><td><strong>Type OF Illness</strong></td><td>: $descptive_illness</td></tr>
				<tr><td><strong>Treatment Type</strong></td><td>: $type_of_treatment</td></tr>
				<tr><td><strong>Admission Status</strong></td><td>: $record_status</td></tr>
				
			  </table>" ;
			  echo "<br /><br /><br /><br /><input type=\"button\" value=\"Print\" onclick=\"print_search()\" />" ;
	
	} else {
		echo "<h1>Record not found</h1>" ;
	}
	
?>