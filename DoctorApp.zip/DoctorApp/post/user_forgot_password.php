<?php
	include "conn.php" ;
	
    date_default_timezone_set('Africa/Johannesburg') ;
    $fromAddr="From: admin@drfinda.com" ;
    ini_set("SMTP", "smtp.vodacom.co.za") ;
    ini_set("SMTP_PORT", 25) ;
    ini_set("sendmail_from","admin@drfinda.com") ;
	
	$email=$_GET["email"];
	$uname=$_GET["uname"];
	
	$subject = "Password recover" ;
	
	$select = "select pwords from logins_tb where unames = '$uname'";
	
	$result = $dbconn->query($select) ;
	
	if ( $result->num_rows > 0 ) {
	
		$row = $result->fetch_assoc() ;
		
		$pword = $row["pwords"] ;
		
		$msg = "Hi, \n A reguest for password recover from this email was a success, your password is : $pword \n Regards \n\n Admin" ;
		
		mail( $email , $subject, $msg, $fromAddr ) ;
		echo "success" ;
	} else {
		echo "Please provide us with a valid username" ;
	}

?>