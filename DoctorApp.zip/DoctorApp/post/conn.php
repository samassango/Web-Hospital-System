<?php

/*
<?php

$mysql_host = "mysql13.000webhost.com";
$mysql_database = "a8336173_hosp";
$mysql_user = "a8336173_boni";
$mysql_password = "450411@tjS";

	$dbconn = new mysqli( "mysql13.000webhost.com", "a8336173_boni", "450411@tjS", "a8336173_hosp" ) ; 

*/

	$dbconn = new mysqli( "localhost", "root", "", "hospital_db_upload" ) ; 
?>