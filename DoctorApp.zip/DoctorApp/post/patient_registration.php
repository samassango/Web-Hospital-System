<?php

	include "conn.php" ;
	
	$name=$_GET["name"];
	$surname=$_GET["surname"];
	$idno=$_GET["idno"];
	$house=$_GET["house"];
	$street=$_GET["street"];
	$postal=$_GET["postal"];
	$pay=$_GET["pay"];
	$med=$_GET["med"];
	$ill=$_GET["ill"];
	$prio=$_GET["prio"];
	
	
	$select = "select * from patients_tb where idnos = '$idno'" ;
	$result = $dbconn->query( $select ) ;
	
	if ( $result->num_rows == 0 ) {
	
		$insert = "insert into patients_tb values('$idno','$name','$surname','$house','$street','$postal','$pay','$med','$ill','$prio')" ;
		
		$result = $dbconn->query( $insert ) ;
		if ( $dbconn->affected_rows == 1 ) {
			echo "Patient successfully added" ;
		} else {
			echo "Failed to add a new patient; Please try again later" ;
		}
	
	} else {
		echo "Patient already registered." ;
	}
?>