<?php
	session_start() ;
	include "conn.php" ;
	
	$idnos = $_SESSION["idnos"] ;
	$search=$_GET["search"] ;
	
	$dates = date( "Y-m-d H:i:s" ) ;

	
	$select = "select * from book_patients_tb where record_status = 'discharged' and p_id = '$search'" ;
	
			
	$result = $dbconn->query( $select ) ;
	
	if ( $result->num_rows == 0 ) {
	    
			
		$select2 =  "select * from book_patients_tb where p_id = '$search'" ;
		$result = $dbconn->query( $select2 ) ;
		if ( $result->num_rows > 0 ) {

			$rows = $result->fetch_assoc() ;
			
			$fcode = $rows["fac_code"] ;
			
			$update_query ="update hospital_facilities_tb set fac_available =fac_available + 1,fac_no_booked =fac_no_booked - 1 where fac_code = '$fcode'";
		    $result1 = $dbconn->query( $update_query ) ;
			if ( $dbconn->affected_rows > 0 ) {
				
				$select = "update book_patients_tb set record_status = 'discharged', reliv_date = '$dates' where p_id = '$search'" ;
				
				$result = $dbconn->query( $select ) ;
				
				if ( $dbconn->affected_rows > 0 ) {
					echo "Patient discharged successfully." ;
				} else {
					echo "Failed to discharge patient." ;	
				}
			}else echo "Error:Failed to discharge patient." ;	
	    }
		
	} else {
		echo "Sorry but this patient was already discharged." ;
	}
?>