-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 23, 2015 at 08:45 AM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hospital_db_upload`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins_tb`
--

CREATE TABLE IF NOT EXISTS `admins_tb` (
  `idnos` varchar(13) NOT NULL,
  `names` varchar(25) NOT NULL,
  `emails` varchar(54) NOT NULL,
  `cells` varchar(12) NOT NULL,
  `hospitals` varchar(25) NOT NULL,
  `adcodes` varchar(13) NOT NULL,
  PRIMARY KEY (`idnos`),
  KEY `surnames` (`emails`,`cells`,`adcodes`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins_tb`
--

INSERT INTO `admins_tb` (`idnos`, `names`, `emails`, `cells`, `hospitals`, `adcodes`) VALUES
('9305245799089', 'Moloko', 'mokolo@kalafong.co.za', '0833532301', 'Kalafong', '90846hh');

-- --------------------------------------------------------

--
-- Table structure for table `book_patients_tb`
--

CREATE TABLE IF NOT EXISTS `book_patients_tb` (
  `bp_code` varchar(13) NOT NULL,
  `p_id` varchar(13) NOT NULL,
  `d_id` varchar(13) NOT NULL,
  `h_id` varchar(15) NOT NULL,
  `date_booked` datetime NOT NULL,
  `descptive_illness` varchar(255) NOT NULL,
  `type_of_treatment` varchar(255) NOT NULL,
  `reliv_date` datetime NOT NULL,
  `record_status` varchar(35) NOT NULL,
  `request_status` varchar(14) NOT NULL,
  KEY `record_status` (`record_status`),
  KEY `h_id` (`h_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_patients_tb`
--

INSERT INTO `book_patients_tb` (`bp_code`, `p_id`, `d_id`, `h_id`, `date_booked`, `descptive_illness`, `type_of_treatment`, `reliv_date`, `record_status`, `request_status`) VALUES
('BKN0000014', '9002035609087', '9009205853080', 'HSO-0000008', '2015-06-06 12:24:46', 'Heart Disease', 'Public', '2015-06-06 12:24:46', 'active', 'Approved'),
('BKN0000015', '9002035609087', '9009205853080', 'HSO-0000001', '2015-06-23 08:41:47', 'Heart Disease', 'Public', '2015-06-23 08:41:47', 'active', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `doctors_tb`
--

CREATE TABLE IF NOT EXISTS `doctors_tb` (
  `idnos` varchar(13) NOT NULL,
  `names` varchar(25) NOT NULL,
  `cells` varchar(12) NOT NULL,
  `emails` varchar(45) NOT NULL,
  `hospitals` varchar(45) NOT NULL,
  `locations` varchar(35) NOT NULL,
  `specials` varchar(45) NOT NULL,
  `prnos` varchar(25) NOT NULL,
  PRIMARY KEY (`idnos`),
  KEY `cells` (`cells`),
  KEY `emails` (`emails`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctors_tb`
--

INSERT INTO `doctors_tb` (`idnos`, `names`, `cells`, `emails`, `hospitals`, `locations`, `specials`, `prnos`) VALUES
('9009205853080', 'ndebele', '0727039498', 'chasfiso@gmail.com', 'Johannesburg Hospital', 'Park Town', 'Heart Surgery', '101');

-- --------------------------------------------------------

--
-- Table structure for table `hospital_facilities_tb`
--

CREATE TABLE IF NOT EXISTS `hospital_facilities_tb` (
  `fac_code` varchar(16) NOT NULL,
  `fac_name` varchar(35) NOT NULL,
  `h_code` varchar(15) NOT NULL,
  PRIMARY KEY (`fac_code`),
  KEY `fac_name` (`fac_name`),
  KEY `h_code` (`h_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hospital_facilities_tb`
--

INSERT INTO `hospital_facilities_tb` (`fac_code`, `fac_name`, `h_code`) VALUES
('1', 'Bed', 'HSO-0000001'),
('10', 'Bed', 'HSO-0000003'),
('11', 'Othorpaedic Operating Theaters', 'HSO-0000003'),
('12', 'Plastic Surgery Operating Theaters', 'HSO-0000003'),
('13', 'Dental with maxillofacial Operating', 'HSO-0000003'),
('14', 'Thoracic Operating theater', 'HSO-0000004'),
('15', 'Neurology Operating Theaters', 'HSO-0000004'),
('16', 'Psychiatric ward', 'HSO-0000005'),
('17', 'Psychiatric ward', 'HSO-0000006'),
('18', 'Psychiatric ward', 'HSO-0000007'),
('19', 'Psychiatric ward', 'HSO-0000008'),
('2', 'Cardiac Operating Theaters', 'HSO-0000001'),
('20', 'Psychiatric ward', 'HSO-0000009'),
('21', 'Psychiatric ward', 'HSO-0000010'),
('22', 'Psychiatric ward', 'HSO-0000011'),
('23', 'Cardiac Operating Theaters', 'HSO-0000005'),
('24', 'Bed', 'HSO-0000005'),
('25', 'Bed', 'HSO-0000007'),
('26', 'Bed', 'HSO-0000010'),
('3', 'Thoracic Operating Theaters', 'HSO-0000001'),
('4', 'Ophthalmology Operating Theaters', 'HSO-0000001'),
('5', 'Bed', 'HSO-0000002'),
('6', 'Neurology Operating Theaters', 'HSO-0000002'),
('7', 'Obstetric Operating Theaters', 'HSO-0000002'),
('8', 'Urology Operating Theaters', 'HSO-0000002'),
('9', 'General Surgery Operating Theaters', 'HSO-0000002');

-- --------------------------------------------------------

--
-- Table structure for table `hostipals_tb`
--

CREATE TABLE IF NOT EXISTS `hostipals_tb` (
  `h_code` varchar(15) NOT NULL,
  `h_name` varchar(35) NOT NULL,
  `h_address` varchar(155) NOT NULL,
  `h_long` varchar(25) NOT NULL,
  `h_lati` varchar(25) NOT NULL,
  PRIMARY KEY (`h_code`),
  KEY `h_long` (`h_long`,`h_lati`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hostipals_tb`
--

INSERT INTO `hostipals_tb` (`h_code`, `h_name`, `h_address`, `h_long`, `h_lati`) VALUES
('HSO-0000001', 'Akasia Private Hospital', 'Pretoria,South Africa', '55.1880560', '-25.7461110'),
('HSO-0000002', 'Dr George Mukhari Public Hospital', '3111 Setlogelo Street 0002', '28.1863800', '-25.7495700'),
('HSO-0000003', 'Bougainville Private Hospital', '0001 block bb', '28.1538600', '-25.7156260'),
('HSO-0000004', 'Jakaranda Hospital', '213 Middelberg Street', '28.1880560', '-25.7461110'),
('HSO-0000005', 'Heart Hospital', '551 Park Street Arcadia', '28.2069800', '-25.7493400'),
('HSO-0000006', 'Gynaecological Hospital', '132 Celliers Street Sunnyside', '28.2099000', '-25.7495000'),
('HSO-0000007', 'Femina Hospital', '460 Belvedere Street Arcadia', '28.2007330', '-25.7403950'),
('HSO-0000008', 'Faerie Glen Hospital', 'C/o Atterbury & Oberon Avenue', '28.2910240', '-25.7832490'),
('HSO-0000009', 'Eugene Hospital', '696 5th Avenue', '28.1943970', '-25.7096810'),
('HSO-0000010', 'Psychiatric Hospital', '507 Lancelot Rd', '28.1634670', '-25.7630290'),
('HSO-0000011', 'Denmar Hospital', '508 Lancelot Rd Garsfontein', '28.1880560', '-25.7461110'),
('HSO-0000012', 'Brooklyn Day Hospital', '154 Olivier Street', '28.1880560', '-25.7461110');

-- --------------------------------------------------------

--
-- Table structure for table `logins_tb`
--

CREATE TABLE IF NOT EXISTS `logins_tb` (
  `unames` varchar(12) NOT NULL,
  `pwords` varchar(12) NOT NULL,
  `utypes` varchar(15) NOT NULL,
  `idnos` varchar(13) NOT NULL,
  PRIMARY KEY (`unames`),
  KEY `utypes` (`utypes`),
  KEY `idnos` (`idnos`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logins_tb`
--

INSERT INTO `logins_tb` (`unames`, `pwords`, `utypes`, `idnos`) VALUES
('gontsi', 'matsatsi', 'Admin', '9202090908087'),
('sfisoT', 'sfisoT', 'Doctor', '9009205853080');

-- --------------------------------------------------------

--
-- Table structure for table `patients_tb`
--

CREATE TABLE IF NOT EXISTS `patients_tb` (
  `idnos` varchar(13) NOT NULL,
  `names` varchar(25) NOT NULL,
  `surnames` varchar(35) NOT NULL,
  `houses` varchar(25) NOT NULL,
  `streets` varchar(25) NOT NULL,
  `postals` varchar(10) NOT NULL,
  `payments` varchar(25) NOT NULL,
  `medicals` varchar(35) NOT NULL,
  `illnesses` varchar(25) NOT NULL,
  `priorty` int(11) NOT NULL,
  PRIMARY KEY (`idnos`),
  KEY `surnames` (`surnames`,`houses`,`payments`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patients_tb`
--

INSERT INTO `patients_tb` (`idnos`, `names`, `surnames`, `houses`, `streets`, `postals`, `payments`, `medicals`, `illnesses`, `priorty`) VALUES
('9002035609087', 'zizipho', 'dlamini', 'halala', 'halala', '203', 'Cash', 'Public', 'Heart Disease', 9),
('9009205853080', 'zizipho', 'ndebele', 'halala', 'halala', '0472', 'Cash', 'Public', 'Heart Disease', 6);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `hospital_facilities_tb`
--
ALTER TABLE `hospital_facilities_tb`
  ADD CONSTRAINT `hospital_facilities_tb_ibfk_1` FOREIGN KEY (`h_code`) REFERENCES `hostipals_tb` (`h_code`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
