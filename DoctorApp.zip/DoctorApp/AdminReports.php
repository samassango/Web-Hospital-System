<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Admin Reports</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
    <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
    <script type="text/javascript" language="javascript" src="js/validation.js"></script>
    <script type="text/javascript" language="javascript">
		function get_patients_booked() {
			location.href = "PatientBooked.php" ;
		}
		
		function get_all_registered_patient() {
			location.href = "PatientList.php" ;
		}
		
		function get_all_registered_doctors() {
			location.href = "DoctorList.php" ;
		}
    </script>
</head>
<body>
	<div class="background">
		<div class="page">
			<a href="index.html" id="logo">Doctor finder</a>
			<div class="sidebar">
				<ul>
					<li>
						<a href="AdminMain.php">Home</a>
					</li>                    
					<li class="selected">
						<a href="AdminReports.php">Reports</a>
					</li>
					<li>
						<a href="patient_discharge.php">Discharge</a>
					</li>
					<li>
						<a href="AdminRequests.php">Requests</a>
					</li>
					<li>
						<a href="login.php">Logout</a>
					</li>
				</ul>
				<!--<?php include "ext/side.php" ; ?>-->
			</div>
			<div class="body">
				<div class="home">
					<!--<?php include "ext/featured.php" ; ?>-->
					<div>
						<div>
							<!--<?php include "ext/main_details.php" ; ?>-->
							<div>
								<br /><br /><h3>REPORTS</h3><br /><br /><br />
                                
                                <div class="errmsg">  </div>
                                
								<input type="button" id="btnBookedPatients" value="Booked Patients" onclick="get_patients_booked()" /><br /><br />
                                <input type="button" id="btnBookedPatients" value="Registered Patient" onclick="get_all_registered_patient()" /><br /><br />
                                <input type="button" id="btnBookedPatients" value="Registered Doctors" onclick="get_all_registered_doctors()" /><br /><br />
                                
							</div>
						</div>
                        
						<!--<?php include "ext/service.php" ; ?>-->
                                        
					</div>
				</div>
			</div>
			<?php include "ext/footer.php" ; ?>
		</div>
	</div>
</body>
</html>