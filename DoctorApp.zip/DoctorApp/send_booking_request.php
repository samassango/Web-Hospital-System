<?php
	session_start() ;
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Doctor finder - Booking request</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
    <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
    <script type="text/javascript" language="javascript">
    	function getPatientFromName(me) {
			
			$.get( "post/get_id_patient.php?name="+me, function(data) {
				$("#divPatient").html(data) ;
			});
		}
		
		function getID(me) { 
			$("#txtPatientID").val(me) ;
			$("#divPatient").html("") ;
		}
		
		function cancelRequest() {
			window.close() ;
		}
		
		function sendRequest() {
			var h_id = $("#txtHospital").val() ;
			var d_id = $("#txtDoctor").val() ;
			var p_id = $("#txtPatientID").val() ;
			var p_fac_code = $("#txtFacCode").val() ;
			var p_fac_n = $("#facilities").val();
			
			$.get( "post/booking_registration.php?h_id="+h_id+"&p_id="+p_id+"&p_fac_code="+p_fac_code, function(data) {
				if ( data.substr(0,7) == "success" ) {
					alert ( "Request successfully sent.") ;
					window.close() ;
				} else {
					alert(data) ;
				}
			});
		}
		/*function getSelectedBox(){
			var vals='';
			var all_loc_id=document.getElementByName('txtFacCode').value;
			for(var i=0;i<all_loc_id.length;i++){
				if(all_loc_id[i].checked)
				vals+=","+all_loc_id[].value;
			}
			return vals;
		}*/
	</script>
</head>
<body>

<div id="divForms" style="width: 350px; background: #033; margin: 20px auto; padding: 20px; border-radius: 5px; border: 1px solid #000; color: #fff;">
	<h1 style="color: #fff;">Make Booking request</h1>

<label for="txtHospital">Hospital code: </label>
<input type='text' id="txtHospital" readonly value="<?php echo $_GET["hcode" ] ; ?>" />
<label for="txtDoctor">Doctor Request code: </label>
<input type='text' id="txtDoctor" readonly value="<?php echo $_SESSION["idnos"] ; ?>" />


<?php
	$hcode = $_GET["hcode" ] ;
	
	include "post/conn.php" ;
	
	$idno = $_SESSION["idnos"] ; 
	
	$select = "select * from hostipals_tb where h_code = '$hcode'" ;
	
	$result = $dbconn->query( $select ) ;
	
	if ( $result->num_rows > 0 ) {
		echo "<table>" ;
		for ( $i = 0; $i < $result->num_rows; $i++ ) {
			$rows = $result->fetch_assoc() ;
			
			$h_code = $rows["h_code"] ;
			$h_name = $rows["h_name"] ;
			
			//Get list of facilities for hospital
			//
			// Full texts 	fac_code 	fac_name 	h_code Ascending
			$select_facility = "select * from hospital_facilities_tb where  h_code = '$h_code'" ;

			$result_facility = $dbconn->query( $select_facility ) ;
			
			$fc_name = "no facilities found." ;
			
			
			
			if ( $result_facility->num_rows > 0 ) {
				$fc_name = "" ;
				echo "<table style='width: 150px;'>" ;
				for ( $j = 0; $j < $result_facility->num_rows; $j++ ) {
					$rows_facility = $result_facility->fetch_assoc() ;
					
					$fc_ward = $rows_facility["fac_ward_name"] ;
					$fc_name = $rows_facility["fac_name"] ; 
					$fc_available = $rows_facility["fac_available"] ; 
					$f_code = $rows_facility["fac_code"] ; 

				?>
                <!--<tr><td><input type='checkbox' id="txtfaci<?php echo $j ; ?>" value="<?php echo $fc_name; ?>" /></td>-->
				    <tr><td><input type='checkbox' id="txtFacCode" name="txtFacCode[]" value="<?php echo $f_code; ?>" /></td>
                	<td><label for="txtfaci<?php echo $j ; ?>"><?php echo $fc_ward." Available ".$fc_name ." is ".$fc_available ; ?> </label></td>
                	<!--<input type="hidden" id="txtFacCode" value="<?php echo $f_code; ?>" />-->
                 </tr>
				
                <?php
					
				}
				echo "</table>" ;
			}
		}
	}
?> 
<label for="txtPatientID">Patient Name </label>
<input type='text' id="txtPatientID" value="" onKeyUp="getPatientFromName(this.value)" />
<div id="divPatient">&nbsp;</div>
<input type='button' value="Send Request" onclick="sendRequest()" />
<input type='button' value="Cancel" onclick="cancelRequest()" />
</div>

</body>
</html>