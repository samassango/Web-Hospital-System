<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Doctor finder - Doctor Details</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
    <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
    <script type="text/javascript" language="javascript" src="js/validation.js"></script>
    <script type="text/javascript" language="javascript">
		function recovery() {
			
			var mes = "" ;
			
			var vbol = false ;
			
			var name = $("#txtName").val() ;
			var idno = $("#txtIDNO").val() ;
			var email = $("#txtEmail").val() ;
			var acode = $("#txtAdminCode").val() ;
			var cell = $("#txtCellnumber").val() ;
			var hospital = $("#txtPracticehospital").val() ;
			
			if ( string_spaces(name) == false || name.length < 3 ) {
				mes += "\n > Please provide a valid name." ;
				vbol = true ;
			}
			
			if ( ValidateIDnumber(idno) == false ) {
				mes += "\n > Please provide a valid RSA ID." ;
				vbol = true ;
			}
			
			if ( email_address(email) == false ) {
				mes += "\n > Please provide a valid email." ;
				vbol = true ;
			}
			
			var two = cell.substr(1,2) ;
			
			if ( cell_code(two) == false || cell.length != 10 ) {
				mes += "\n > Please provide a valid cell number." ;
				vbol = true ;				
			}
			
			if ( alphanumeric(acode) == false || acode.length < 3 ) {
				mes += "\n > Please provide a valid practice code." ;
				vbol = true ;
			}
			
			if ( string_spaces(hospital) == false || hospital.length < 3 ) {
				mes += "\n > Please provide a valid hospital name." ;
				vbol = true ;
			}
		
			var str = "name=" + name + 
					  "&idno=" + idno +
					  "&cell=" + cell +
					  "&email=" + email +
					  "&acode=" + acode +
					  "&hospital=" + hospital ;
					  
			if ( vbol == false ) {
			
				$.get( "post/admin_registration.php?" + str, function(data) {
					if ( data.substr(0,7) == "success" ) {
						$("#txtName").val("") ;
						$("#txtIDNO").val("") ;
						$("#txtEmail").val("") ;
						$("#txtAdminCode").val("") ;
						$("#txtCellnumber").val("") ;
						$("#txtPracticehospital").val("") ;
						location.href = "login.php" ;		
					} else {
						alert( data ) ;	
					}
				});
			
			} else {
				alert( mes ) ;
			}
		}
    </script>
</head>
<body>
	<div class="background">
		<div class="page">
        	
			<a href="index.html" id="logo">Doctor finder</a>
			<div class="sidebar">
				<ul>
					<li>
						<a href="index.php">Home</a>
					</li>
					<li>
						<a href="register.php">Register</a>
					</li>
					<li class="selected">
						<a href="login.php">Login</a>
					</li>
				</ul>
				<!--<?php include "ext/side.php" ; ?>-->
			</div>
			<div class="body">
				<div class="home">
					<!--<?php include "ext/featured.php" ; ?>-->
					<div>
						<div>
							<!--<?php include "ext/main_details.php" ; ?>-->
							<div>
								<br /><br /><h3>Admin Details</h3><br /><br /><br />
                                
                                <div class="errmsg">  </div>
                                
								<form>
                                	<label for="txtIDNO">IDNO:</label>
                                    <input type="text" id="txtIDNO" name="txtIDNO" /><br />
                                	<label for="txtName">Name:</label>
                                    <input type="text" id="txtName" name="txtName" /><br />
                                	<label for="txtAdminCode">Admin Code:</label>
                                    <input type="text" id="txtAdminCode" name="txtAdminCode" /><br />
                                	<label for="txtPracticehospital">Practice hospital:</label>
                                    <input type="text" id="txtPracticehospital" name="txtPracticehospital" /><br />
                                	<label for="txtEmail">Email:</label>
                                    <input type="text" id="txtEmail" name="txtEmail" /><br />
                                	<label for="txtCellnumber">Cell number:</label>
                                    <input type="text" id="txtCellnumber" name="txtCellnumber" /><br /><br /><br />
                                    
                                    <input type="button" value="Register" onclick="recovery()" />
                                </form>
							</div>
						</div>
                        
						<!--<?php include "ext/service.php" ; ?>-->
                                        
					</div>
				</div>
			</div>
			<?php include "ext/footer.php" ; ?>
		</div>
	</div>
</body>
</html>