<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Doctor finder - Registration</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
    <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
    <script type="text/javascript" language="javascript" src="js/validation.js"></script>
    <script type="text/javascript" language="javascript">
		function login_register() {
			
			var mes = "" ;
			
			var vbol = false ;
			
			var uname = $("#txtUsername").val() ;
			var pword = $("#txtPassword").val() ;
			var cpword = $("#txtConfPassword").val() ;
			var utype = $("#txtUsertype").val() ;
			var idno = $("#txtIdNumber").val() ;
			
			if ( alphanumeric(uname) == false || uname.length < 6 ) {
				mes += "\n > Please provide a valid username." ;
				vbol = true ;
			}
			
			if ( alphanumeric(pword) == false || pword.length < 6 ) {
				mes += "\n > Please provide a valid password." ;
				vbol = true ;
			}
			
			if ( pword != cpword ) {
				mes += "\n > Please confirm password." ;
				vbol = true ;
			}
			
			if ( document.getElementById("txtUsertype").selectedIndex == 0 ) {
				mes += "\n > Please select a user type." ;
				vbol = true ;
			}
			
			if ( ValidateIDnumber(idno) == false ) {
				mes += "\n > Please provide a valid RSA ID." ;
				vbol = true ;
			}
			
			var str = "uname=" + uname + "&pword=" + pword + "&utype=" + utype + "&idno=" + idno ;
			
			if ( vbol == false ) {
				if ( uname.length > 5 && pword.length > 5 && pword == cpword && document.getElementById("txtUsertype").selectedIndex > 0 ) {
					$.get( "post/user_registration.php?" + str, function(data) {
						if ( data == "Patient" ) {
							location.href = "Patient.php" ;	
						} else if ( data.substr(0,6) == "Doctor" ) {
							location.href = "doctor.php" ;	
						} else if ( data.substr(0,5) == "Admin" ) {
							location.href = "admin.php" ;	
						} else {
							alert( data ) ;	
						}
					});
				
				} else {
					alert( "Please fill in the form" ) ;
				}
			} else {
				alert( mes ) ;
			}
		}
    </script>
</head>
<body>
	<div class="background">
		<div class="page">
			<a href="index.html" id="logo">Doctor finder</a>
			<div class="sidebar">
				<ul>
					<li>
						<a href="index.php">Home</a>
					</li>
					<li class="selected">
						<a href="register.php">Register</a>
					</li>
					<li>
						<a href="login.php">Login</a>
					</li>
				</ul>
				<!--<?php include "ext/side.php" ; ?>-->
			</div>
			<div class="body">
				<div class="home">
					<!--<?php include "ext/featured.php" ; ?>-->
					<div>
						<div>
							<!--<?php include "ext/main_details.php" ; ?>-->
							<div>
								<br /><br /><h3>Create account</h3><br /><br /><br />
                                
                                <div class="errmsg">  </div>
                                
								<form>
                                	<label for="txtUsername">Username:</label>
                                    <input type="text" id="txtUsername" name="txtUsername" /><br />
                                	<label for="txtPassword">Password:</label>
                                    <input type="password" id="txtPassword" name="txtPassword" /><br />
                                	<label for="txtConfPassword">Confirm Password:</label>
                                    <input type="password" id="txtConfPassword" name="txtConfPassword" /><br />
                                    <label for="txtUsertype">User type:</label>
                                    <select id="txtUsertype">
                                    	<option>Please select</option>
                                        <option value="Admin">Admin</option>
                                        <option value="Doctor">Doctor</option>
                                    </select>
                               		<label for="txtIdNumber">Id Number:</label>
                                    <input type="text" id="txtIdNumber" name="txtIdNumber" /><br />
                                    
                                    <input type="button" value="Back" onclick="location.href='index.php'" />
                                    <input type="button" value="Next" onclick="login_register()" />
                                </form>
							</div>
						</div>
                        
						<!--<?php include "ext/service.php" ; ?>-->
                                        
					</div>
				</div>
			</div>
			<?php include "ext/footer.php" ; ?>
		</div>
	</div>
</body>
</html>