<?php
	session_start() ;
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Doctor finder - Search nearest hospital</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
    <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
    <script type="text/javascript" language="javascript">
		function getHospital(code,name, f_list) {
			//var flag = confrim( "This is my selected hospital: " + name )
			var str = f_list.replace(/\ - /g, '\n\n');
			
			if ( confirm( "Facilities offered at: " + name + "\n___________________________________________________________\n" + str ) ) {
				var ref = window.open('send_booking_request.php?hcode='+code, '_blank', 'location=yes');
			}
		}
	</script>
</head>
<body>
	<div class="background">
		<div class="page">
        	
			<a href="index.html" id="logo">Doctor finder</a>
			<div class="sidebar">
				<ul>
					<li>
						<a href="doctor_menu.php">Home</a>
					</li>
					<li>
						<a href="add_patient.php">Add Patient</a>
					</li>
					<li>
						<a href="view_patient_requests.php">View Requests</a>
					</li>
					<li class="selected">
						<a href="search_nearest_hospital.php">Search</a>
					</li>
					<li>
						<a href="login.php">Logout</a>
					</li>
				</ul>
			</div>
			<div class="body">
				<div class="home">
					<div>
						<div>
							<div>
								<br /><br /><h3>List of all nearest hospital</h3><br />
                                
                                <div class="errmsg">  </div>
                                
								<div>
                                	<?php
											include "post/conn.php" ;
											
											$idno = $_SESSION["idnos"] ; 
											
											$select = "select * from hostipals_tb" ;
											
											$result = $dbconn->query( $select ) ;
											
											if ( $result->num_rows > 0 ) {
												echo "<table>" ;
												for ( $i = 0; $i < $result->num_rows; $i++ ) {
													$rows = $result->fetch_assoc() ;
													
													$h_code = $rows["h_code"] ;
													
													$h_name = $rows["h_name"] ;
													$h_long = $rows["h_long"] ;
													$h_lati = $rows["h_lati"] ;
													
													$address = getaddress($h_lati,$h_long) ;
													
													$lat2 = "-25.5457253" ;
													$lon2 = "28.0967964" ;
													
													//Get list of facilities for hospital
													//
													// Full texts 	fac_code 	fac_name 	h_code Ascending
													$select_facility = "select * from hospital_facilities_tb where h_code = '$h_code'" ;
									
													$result_facility = $dbconn->query( $select_facility ) ;
													
													$fc_name = "no facilities found." ;
													
													
													
													if ( $result_facility->num_rows > 0 ) {
														$fc_name = "" ;
														for ( $j = 0; $j < $result_facility->num_rows; $j++ ) {
															$rows_facility = $result_facility->fetch_assoc() ;
															
															$fc_name .= ( $j+1 ) ."  " . $rows_facility["fac_ward_name"] . "  Available " . $rows_facility["fac_name"] ."  is " . $rows_facility["fac_available"] . " - " ; 
															
														}
													} 
													
													?>
                                                    	<tr>
                                                        	<td>
                                                            	<a href='#' onclick="getHospital('<?php echo $h_code ; ?>',
                                                                								 '<?php echo $h_name ; ?>',
                                                                                                 '<?php echo $fc_name ; ?>')">
                                                                <h1><?php echo $h_name ; ?></h1>
                                                                </a>
                                                                <p><?php echo "Latitude: " . $h_lati . "<br/>Latitude: " . $h_long ; ?></p>
                                                                <p><?php echo "Address: " . $address ; ?></p>
                                                                
                                                                <p><?php echo "Distance: " . round(( returnAll2KmAway($h_lati, $h_long, $lat2, $lon2) / 1000 ),2) . " KM" ; ?></p>
                                                            </td>
                                                         </tr>
                                                    <?php
												}
												echo "</table>" ;
											}
										function getaddress($lat,$lng) {
											$url = 'http://maps.googleapis.com/maps/api/geocode/json?latlng='.trim($lat).','.trim($lng).'&sensor=false';
											$json = @file_get_contents( $url ) ;
											$data=json_decode( $json );
											$status = $data->status;
											if( $status=="OK" )
												return $data->results[0]->formatted_address;
											else
												return false;
										}
										//Function return all registered 2KM alway from my panic situation.
										//
										function returnAll2KmAway($lat1, $lon1, $lat2, $lon2) {
										   $theta = $lon1 - $lon2;
										   $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
										   $dist = acos($dist);
										   $dist = rad2deg($dist);
										   
										   $miles = $dist * 60 * 1.1515;
										   return round(($miles * 1.609344), 2);
										}
									?>
                                </div>
							</div>
						</div>
                                        
					</div>
				</div>
			</div>
			<?php include "ext/footer.php" ; ?>
		</div>
	</div>
</body>
</html>