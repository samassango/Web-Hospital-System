        // --------------------------------------------------------------------------------------
	// this method will validate only words not
	function string_spaces(str) {
		var isValid = true;
		var validChars = "abcdefghijklmnopqrstuvwxyz ";
		var charIndex;
		if ( str.length < 3 ) { return false ; }
                else {
		   for (charIndex = 0; charIndex < str.length;charIndex++) {
			if ( validChars.indexOf( str.charAt(charIndex).toLowerCase() ) < 0 ) {
				isValid = false; break;
			}
		   }
                }
		if ( isValid == true ) return true; else return false;
	}
	// --------------------------------------------------------------------------------------
	// this method will validate only numeric values.
	function all_number(str) {
		var isValid = true;
		var validChars = "0123456789";
		var charIndex;
		if ( str.length < 3 ) { return false ; }
                else {
		   for (charIndex = 0; charIndex < str.length;charIndex++) {
			if ( validChars.indexOf( str.charAt(charIndex).toLowerCase() ) < 0 ) {
				isValid = false; 
				break;
			}
		   }
                }
		if ( isValid == true ) 
		   return true; 
		else 
		   return false;		
	}
	// --------------------------------------------------------------------------------------
	// this method will validate only float values.
	function all_float(str) {
		var isValid = true;
		var validChars = "0123456789.";
		var charIndex;
		for (charIndex = 0; charIndex < str.length;charIndex++) {
			if ( validChars.indexOf( str.charAt(charIndex).toLowerCase() ) < 0 ) {
				isValid = false; 
				break;
			}
		}
		if ( isValid == true ) 
			return true; 
		else 
			return false;		
	}
	// --------------------------------------------------------------------------------------
	// this method will cvalidate alphanumeric and space.
	function alphanumeric(str) {
		var isValid = true;
		var validChars = "abcdefghijklmnopqrstuvwxyz0123456789-_";
		var charIndex;
			for (charIndex = 0; charIndex < str.length;charIndex++) {
				if ( validChars.indexOf( str.charAt(charIndex).toLowerCase() ) < 0 ) {
					isValid = false; break;
				}
			}
		if ( isValid == true ) return true; else return false;		
	}
	// --------------------------------------------------------------------------------------
	// this method will validate the email address.
	function email_address(email) {
		var mailformat = /^\w+([\.-]?\w)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
		if ( email.match( mailformat ) ) return true; else return false; 
	}
	// --------------------------------------------------------------------------------------
	// this method will check the area code of a phone number.
	function area_code(first_three) {
		var area_codes = [ "049", "058", "013", "042", "046", "054", "028", "011", "053", "027",
						   "040", "051", "014", "031", "035", "017", "039", "015", "056", "023",
						   "018", "021", "012", "022", "044", "032", "045", "036", "043", "028",
						   "047", "034", "055", "033", "016", "052", "057" ];
		
		for ( var i = 0; i < area_codes.length; i++ ) {
			if ( area_codes[i] == first_three ) { return true; break; }
		}
		return false;
	}
	// --------------------------------------------------------------------------------------
	// this method will check the area code of a cell number.
	function cell_code(first_two) {
		var cell_codes = [ "78", "76", "72", "71", "74", "73", "82", "83", "84", "81", "60", "61" ];
		for ( var i = 0; i < cell_codes.length; i++ ) {
			if ( cell_codes[i] == first_two ) { return true; break; }
		}
		return false;		
	}
	// --------------------------------------------------------------------------------------
	function ValidateIDnumber(idnumber) {
		//1. numeric and 13 digits
		if ( isNaN(idnumber) || (idnumber.length != 13 ) ) { 
		   return false; 
		}
		
		//2. first 6 numbers is a valid date
		var tempDate = new Date(idnumber.substring(0, 2), idnumber.substring(2, 4) - 1, idnumber.substring(4, 6));
		var currentTime = new Date(); 
		var  diff = currentTime - tempDate ;
		var age = Math.floor( ( diff / 1000 / (60 * 60 * 24) ) / 365.25 );
		if ( age < 18 ) {
			alert("You dont qualify to vote - you will vote after (" + ( 18 - age ) + ") year(s)") ;
			return false ;
		}
		if (!((tempDate.getYear() == idnumber.substring(0, 2)) 
			&& (tempDate.getMonth() == idnumber.substring(2, 4) - 1) 
			&& (tempDate.getDate() == idnumber.substring(4, 6)))) { 
		   return false; 
		}
		
		//3. luhn formula
		var tempTotal = 0; 
		var checkSum = 0; 
		var multiplier = 1;
		for (var i = 0; i < 13; ++i) {
		   tempTotal = parseInt(idnumber.charAt(i)) * multiplier;
		   if (tempTotal > 9) { 
			 tempTotal = parseInt(tempTotal.toString().charAt(0)) + parseInt(tempTotal.toString().charAt(1)); 
		   }
		   checkSum = checkSum + tempTotal;
		   multiplier = ( multiplier % 2 == 0 ) ? 1 : 2;
		}
		if ((checkSum % 10) == 0) { return true; } else { return false; }
	}
	// --------------------------------------------------------------------------------------
