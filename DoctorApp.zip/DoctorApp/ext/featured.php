<div class="featured">
						<img src="images/Vaccination1.jpg" width="720" height="341" alt="">
						<div>
							<p>
Doctor finder’s goal is to improve lives and communities in South Africa by increasing reach and access to psychosocial support.
							</p>
						</div>
					</div>