<div class="footer">
				<div>
					<div>
						<h4>Blog</h4>
						<p>
							Our Website blog
						</p>
						<a href="#" onclick="javascript:alert('Our blog is currently disabled; Please try again later')">Go To Blog</a>
					</div>
					<div>
						<h4>Quick links</h4>
						<ul>
							<li>
								<a href="index.php">Home</a>
							</li>
							<li>
								<a href="register.php">Register</a>
							</li>
							<li>
								<a href="login.php">Login</a>
							</li>
						</ul>
					</div>
					<div class="connect">
						<h4>Keep In Touch</h4>
						<a href="http://twitter.com/@doctorfinder12" id="twitter">twitter</a> 
                        <a href="http://facebook.com/bonisithole" id="facebook">facebook</a> 
                        <a href="http://google.com" id="googleplus">google+</a>
					</div>
				</div>
				<p>
					&#169; Copyright 2012. All rights reserved
				</p>
			</div>