						<div>
							<h4>Types of theater can be:</h4>
							<a href="services.html"><img src="images/services.jpg" alt=""></a>
							<ul>
								<li>
									<a href="services.html">Cardiac</a>
								</li>
								<li>
									<a href="services.html">Thoracle</a>
								</li>
								<li>
									<a href="services.html">Ophthalmology</a>
								</li>
								<li>
									<a href="services.html">Neurology</a>
								</li>
								<li>
									<a href="services.html">Urolgy</a>
								</li>
								<li>
									<a href="services.html">General Surgery</a>
								</li>
								<li>
									<a href="services.html">Othorpeadic</a>
								</li>
								<li>
									<a href="services.html">Dental with maxill of acial operating theater</a>
								</li>
							</ul>
							
						</div>
        