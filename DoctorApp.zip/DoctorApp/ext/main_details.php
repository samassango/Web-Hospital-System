<div>
								<h3>Welcome to Doctor finder</h3><br />
								<p>
Doctor finder is an interactive online health directory featuring medical doctors in all fields of expertise including health clinics, hospitals and medical institutions.

Potential patients can find relevant specialist medical care, information and services on their specific needs from appropriate experts or obtain a second opinion.

General practitioners and referring professionals can find suitable medical specialists to refer to their patients, thus also facilitating a symbiotic platform for doctor and patient relationships.

Medical doctors and health care professionals can apply online to receive your own unique web page, introducing your specialty, your practice and your services to the World Wide Web.
								</p>
								<span><a href="programs.html">Learn More</a></span>
							</div>