				<div class="first">
					<div>
						<h3>South African Minister</h3>
						<img src="images/aron.jpg" width="180" height="172" alt="">
						<p>
In the South African government, the Minister of Health is the member of the national Cabinet responsible for the Department of Health, and therefore for national health policy and the administration of public health. The position is of particular importance in South Africa because of the massive impact of the AIDS pandemic in the country.
						</p>
					</div>
				</div>
				<div>
					<div>
						<h3>Article</h3>
						<img src="images/SA-Junior-Dr-October-2012-cover-200.jpg" alt="">
						<p>
							As a junior doctor, your intern and community service years can be tough. Not only have you to put your clinical knowledge into practice, you have to get to grips with treating patients whose symptoms – and behaviours – might not always match up to the textbook examples you learnt about in medical school.
						</p>
					</div>
				</div>