<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Doctor finder - Patient Details</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
    <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
    <script type="text/javascript" language="javascript" src="js/validation.js"></script>
    <script type="text/javascript" language="javascript">
		function recovery() {
			var mes = "" ;
			
			var vbol = false ;
			
			 var edtName = $("#edtName").val() ;             
			 var edtSurname = $("#edtSurname").val() ;  
			 var edtIDNO = $("#edtIDNO").val() ;   
			 var edtHouse = $("#edtHouse").val() ;  
			 var edtStreet = $("#edtStreet").val() ; 
			 var edtPostal = $("#edtPostal").val() ; 
			 var edtPayment = $("#edtPayment").val() ; 
			 var edtMedical = $("#edtMedical").val() ; 
			 var edtIllness = $("#edtIllness").val() ; 
			 var edtPriority = $("#edtPriority").val() ;
			 
			if ( string_spaces(edtName) == false || edtName.length < 3 ) {
				mes += "\n > Please provide a valid name." ;
				vbol = true ;
			}
			
			if ( string_spaces(edtSurname) == false || edtSurname.length < 3 ) {
				mes += "\n > Please provide a valid surname." ;
				vbol = true ;
			}
			
			if ( ValidateIDnumber(edtIDNO) == false ) {
				mes += "\n > Please provide a valid RSA ID." ;
				vbol = true ;
			}
			 
			 var str = "name="+edtName+
					   "&surname="+edtSurname+
					   "&idno="+edtIDNO+
					   "&house="+edtHouse+
					   "&street="+edtStreet+
					   "&postal="+edtPostal+
					   "&pay="+edtPayment+
					   "&med="+edtMedical+
					   "&ill="+edtIllness+
					   "&prio="+edtPriority ;
			if ( vbol == false ) {		
				$.get( "post/patient_registration.php?" + str, function(data) {
					alert( data )
					if ( data == "Patient successfully added" ) { 

						 $("#edtName").val("") ;             
						 $("#edtSurname").val("") ;  
						 $("#edtIDNO").val("") ;   
						 $("#edtHouse").val("") ;  
						 $("#edtStreet").val("") ; 
						 $("#edtPostal").val("") ; 
						 $("#edtPayment").val("") ; 
						 $("#edtMedical").val("") ; 
						 $("#edtIllness").val("") ; 
						 $("#edtPriority").val("") ;						
						
						location.href = "doctor_menu.php" ;
					
					}
				});
			} else {
				alert( mes ) ;
			}
		}
    </script>
</head>
<body>
	<div class="background">
		<div class="page">
        	
			<a href="index.html" id="logo">Doctor finder</a>
			<div class="sidebar">
				<ul>
					<li>
						<a href="doctor_menu.php">Home</a>
					</li>
					<li>
						<a href="admit_patient.php">Admit Patient</a>
					</li>
					<li>
						<a href="patient_report.php">Patient Report</a>
					</li>
					<li>
						<a href="patient_discharge.php">Discharge</a>
					</li>
					<li class="selected">
						<a href="patient.php">New Patient</a>
					</li>
					<li>
						<a href="login.php">Logout</a>
					</li>
				</ul>
				<!--<?php include "ext/side.php" ; ?>-->
			</div>
			<div class="body">
				<div class="home">
					<!--<?php include "ext/featured.php" ; ?>-->
					<div>
						<div>
							<!--<?php include "ext/main_details.php" ; ?>-->
							<div>
								<br /><br /><h3>Patient</h3><br /><br /><br />
                                
                                <div class="errmsg">  </div>
                                
								<form>
                                     <label for="edtName">Name</label>
                                     <input type="text" name="edtName" id="edtName" value=""><br />             
                                     <label for="edtSurname">Surname</label>
                                     <input type="text" name="edtSurname" id="edtSurname" value=""><br />  
                                     <label for="edtIDNO">Id NO#</label>
                                     <input type="text" name="edtIDNO" id="edtIDNO" value=""><br />  
                                     <label for="edtHouse">House number</label>
                                     <input type="text" name="edtHouse" id="edtHouse" value=""><br />  
                                     <label for="edtStreet">Street name</label>
                                     <input type="text" name="edtStreet" id="edtStreet" value=""><br /> 
                                     <label for="edtPostal">Postal Code</label>
                                     <input type="text" name="edtPostal" id="edtPostal" value=""><br /> 
                                     <label for="edtPayment">Type Of Payment</label><br />
                                     <select name="edtPayment" id="edtPayment">
                                        <option value="">Please select</option>
                                        <option value="Cash">Cash</option>
                                        <option value="Medical">Medical</option>
                                     </select><br /> 
                                     <label for="edtUsername">Medical Type</label>
                                     <select name="edtMedical" id="edtMedical">
                                        <option value="">Please select</option>
                                        <option value="Public">Public</option>
                                        <option value="Private">Private</option>
                                     </select><br /> 
                                     <label for="edtIllness">Type Of Illness</label>
                                     <textarea name="edtIllness" id="edtIllness" value=""></textarea><br /> 
                                     <select name="edtPriority" id="edtPriority">
                                        <option value="">Please select</option>
                                        <?php
                                            for ( $i=1; $i < 11; $i++ )
                                                echo "<option value='$i'>$i</option>" ;
                                        ?>
                                     </select><br /><br /><br />
                                    
                                    <input type="button" value="Register" onclick="recovery()" />
                                </form>
							</div>
						</div>
                        
						<!--<?php include "ext/service.php" ; ?>-->
                                        
					</div>
				</div>
			</div>
			<?php include "ext/footer.php" ; ?>
		</div>
	</div>
</body>
</html>