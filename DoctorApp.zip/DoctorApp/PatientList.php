<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Admin Reports - Registered Doctors</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
    <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
    <script type="text/javascript" language="javascript" src="js/validation.js"></script>
    <script type="text/javascript" language="javascript">
		
    </script>
</head>
<body>
	<div class="background">
		<div class="page">
			<a href="index.html" id="logo">Doctor finder</a>
			<div class="sidebar">
				<ul>
					<li>
						<a href="AdminMain.php">Home</a>
					</li>
					<li  class="selected">
						<a href="AdminReports.php">Reports</a>
					</li>
					<li>
						<a href="patient_discharge.php">Discharge</a>
					</li>
					<li>
						<a href="AdminRequests.php">Requests</a>
					</li>
					<li>
						<a href="login.php">Logout</a>
					</li>
				</ul>
				<!--<?php include "ext/side.php" ; ?>-->
			</div>
			<div class="body">
				<div class="home">
					<!--<?php include "ext/featured.php" ; ?>-->
					<div>
						<div>
							<!--<?php include "ext/main_details.php" ; ?>-->
							<div>
								<br /><h3>All Registed Doctors</h3><br />
                                
                                <div class="errmsg">  </div>
                                
								<?php
								
									include "post/conn.php" ;
									
									$select = "select * from patients_tb" ;
									
									$result = $dbconn->query( $select ) ;
									
									if ( $result->num_rows > 0 ) {
										?>
                                        	<table border="1" bordercolor="#333333" cellpadding="5" cellspacing="0" style="font-size: 10px;">
                                            	<tr bgcolor="#333333" style="color:#fff;">
                                                    <th>Patient names</th>
                                                    <th>Patient address</th>
                                                    <th>Patient payment</th>
                                                    <th>Patient medical #</th>
                                                    <th>Patient illness</th>
                                                    <th>Patient attendence priorty</th>
                                                </tr>
                                        <?php
										
										for ( $i = 0; $i < $result->num_rows; $i++ ) {
											$row = $result->fetch_assoc() ;
											
											$p_id = $row["names"]. "  " .$row["surnames"] ;
											$d_id = $row["houses"] . "<br />" . $row["streets"]  ;
											$date_booked = $row["payments"] ;
											$descptive_illness = $row["medicals"] ;
											$type_of_treatment = $row["illnesses"] ;
											$reliv_date = $row["priorty"] ;
											
											?>
                                            	<tr bgcolor="#ffffff">
                                                    <th><?php echo $p_id ; ?></th>
                                                    <th><?php echo $d_id ; ?></th>
                                                    <th><?php echo $date_booked ; ?></th>
                                                    <th><?php echo $descptive_illness ; ?></th>
                                                    <th><?php echo $type_of_treatment ; ?></th>
                                                    <th><?php echo $reliv_date . "/10" ; ?></th>
                                                </tr>                                            	
                                            <?php
	
										}
										
									} else {
									
										echo "<h1>No records found</h1>" ;	
										
									}
									
									
								?>
                                </table>
                                <h4 align="center"><a href="post/doc_patient_list.php">.doc</a><a href="post/pdf_patient_list.php">.pdf</a></h4>
							</div>
						</div>
                        
						<!--<?php include "ext/service.php" ; ?>-->
                                        
					</div>
				</div>
			</div>
			<?php include "ext/footer.php" ; ?>
		</div>
	</div>
</body>
</html>