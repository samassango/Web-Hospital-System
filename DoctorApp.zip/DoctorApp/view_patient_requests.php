<?php
	session_start() ;
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Doctor finder - Doctor Details</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
    <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
</head>
<body>
	<div class="background">
		<div class="page">
        	
			<a href="index.html" id="logo">Doctor finder</a>
			<div class="sidebar">
				<ul>
					<li>
						<a href="doctor_menu.php">Home</a>
					</li>
					<li>
						<a href="add_patient.php">Add Patient</a>
					</li>
					<li class="selected">
						<a href="view_patient_requests.php">View Requests</a>
					</li>
					<li>
						<a href="search_nearest_hospital.php">Search</a>
					</li>
					<li>
						<a href="login.php">Logout</a>
					</li>
				</ul>
			</div>
			<div class="body">
				<div class="home">
					<div>
						<div>
							<div>
								<br /><br /><h3>Doctors Main Board</h3><br /><br /><br />
                                
                                <div class="errmsg">  </div>
                                
								<div>
                                
								<?php
								
									include "post/conn.php" ;
									
									$select = "select * from book_patients_tb" ;
									
									$result = $dbconn->query( $select ) ;
									
									$count_p = "0" ;
									$count_a = "0" ;
									$count_c = "0" ;
									
									if ( $result->num_rows > 0 ) {
										?>
                                        	<table border="1" bordercolor="#333333" cellpadding="5" cellspacing="0" style="font-size: 10px;">
                                            	<tr bgcolor="#333333" style="color:#fff;">
                                                    <th>Patient Name#</th>
                                                    <th>Date Booked</th>
                                                    <th>Patient Illness</th>
                                                    <th>Status</th>
                                                </tr>
                                        <?php
										
										for ( $i = 0; $i < $result->num_rows; $i++ ) {
											$row = $result->fetch_assoc() ;
											
											$bp_code = $row["bp_code"] ; 
											$p_id = $row["p_id"] ;
											$d_id = $row["d_id"] ;
											$date_booked = $row["date_booked"] ;
											$descptive_illness = $row["descptive_illness"] ;
											$type_of_treatment = $row["type_of_treatment"] ;
											$reliv_date = $row["reliv_date"] ;
											$request_status = $row["request_status"] ;
											
											if ( $request_status == "Pending" ) 
												$count_p++ ;
											if ( $request_status == "Approved" )
												$count_a++ ;
											else
												$count_c++ ;
												
												
											$select_patients = "select * from patients_tb where idnos = '$p_id'" ;
											
											$result_patients = $dbconn->query( $select_patients ) ;
											
											if ( $result_patients->num_rows > 0 ) {
												for ( $j = 0; $j < $result_patients->num_rows; $j++ ) {
													$rows_patients = $result_patients->fetch_assoc() ;
													
													$p_id = $rows_patients["names"] . " " .$rows_patients["surnames"] ;
												}
											} else {
												echo "<tr><td colspan='4'>Record moved to history file</td></tr>" ;	
											}
																							
											?>
                                            	<tr bgcolor="#ffffff">
                                                    <td><?php echo $p_id ; ?></td>
                                                    <td><?php echo $date_booked ; ?></td>
                                                    <td><?php echo $descptive_illness ; ?></td>
                                                    <?php if ( $request_status != "" ) { ?>
                                                    <td><?php echo $request_status ; ?></td>
                                                    <?php } else { ?>
                                                    <td><?php echo "Broken status" ; ?></td>
                                                    <?php } ?>
                                                </tr>                                            	
                                            <?php
	
										}
										echo "</table>" ;
										echo "<h4>
												Pending Requests: $count_p<br />
												Approved Requests: $count_a<br />
												Incomplete Requests: $count_c<br />
											  </h4>" ;
									} else {
									
										echo "<h1>No records found</h1>" ;	
										
									}
									
									
								?>

                                </div>
							</div>
						</div>
                                        
					</div>
				</div>
			</div>
			<?php include "ext/footer.php" ; ?>
		</div>
	</div>
</body>
</html>