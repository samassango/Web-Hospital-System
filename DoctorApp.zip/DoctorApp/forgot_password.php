<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Doctor finder - Recovery</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
    <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
    <script type="text/javascript" language="javascript" src="js/validation.js"></script>
    <script type="text/javascript" language="javascript">
		function recovery() {
			var uname = $("#txtUsername").val() ;
			var email = $("#txtEmail").val() ;
		
			var str = "uname=" + uname + "&email=" + email ;
			
			$.get( "post/user_forgot_password.php?" + str, function(data) {
				if ( data.substr(0,7) == "success" ) {
					location.href = "index.php" ;		
				} else {
					alert( data ) ;	
				}
			});
		}
    </script>
</head>
<body>
	<div class="background">
		<div class="page">
			<a href="index.html" id="logo">Doctor finder</a>
			<div class="sidebar">
				<ul>
					<li>
						<a href="index.php">Home</a>
					</li>
					<li>
						<a href="register.php">Register</a>
					</li>
					<li class="selected">
						<a href="login.php">Login</a>
					</li>
				</ul>
				<!--<?php include "ext/side.php" ; ?>-->
			</div>
			<div class="body">
				<div class="home">
					<!--<?php include "ext/featured.php" ; ?>-->
					<div>
						<div>
							<!--<?php include "ext/main_details.php" ; ?>-->
							<div>
								<br /><br /><h3>Forgot Password</h3><br /><br /><br />
                                
                                <div class="errmsg">  </div>
                                
								<form>
                                	<label for="txtUsername">Username:</label>
                                    <input type="text" id="txtUsername" name="txtUsername" /><br />
                                	<label for="txtEmail">Email:</label>
                                    <input type="password" id="txtEmail" name="txtEmail" /><br /><br /><br />
                                    
                                    <input type="button" value="Password Recovery" onclick="recovery()" />
                                </form>
							</div>
						</div>
                        
						<!--<?php include "ext/service.php" ; ?>-->
                                        
					</div>
				</div>
			</div>
			<?php include "ext/footer.php" ; ?>
		</div>
	</div>
</body>
</html>