<?php
	session_start() ;
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Doctor finder - Patient Discharge</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
    <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
    <script type="text/javascript" language="javascript" src="js/validation.js"></script>
    <script type="text/javascript" language="javascript">
		function discharge_booking() {
			var idno = $("#txtPatientID").val() ;
		
			var str = "search=" + idno ;
			
			$.get( "post/discharge_patients.php?" + str, function(data) {
			   alert( data ) ;	
			});
		}
		
    	function getPatientFromName(me) {
			
			$.get( "post/get_id_patient.php?name="+me, function(data) {
				$("#divPatient").html(data) ;
			});
		}
		
		function getID(me) { 
			$("#txtPatientID").val(me) ;
			$("#divPatient").html("") ;
		}
	</script>
</head>
<body>
	<div class="background">
		<div class="page">
        	
			<a href="index.html" id="logo">Doctor finder</a>
			<div class="sidebar">
				<ul>
					<li>
						<a href="AdminMain.php">Home</a>
					</li>                    
					<li>
						<a href="AdminReports.php">Reports</a>
					</li>
					<li class="selected">
						<a href="patient_discharge.php">Discharge</a>
					</li>
					<li>
						<a href="AdminRequests.php">Requests</a>
					</li>
					<li>
						<a href="login.php">Logout</a>
					</li>
				</ul>
			</div>
			<div class="body">
				<div class="home">
					<div>
						<div>
							<div>
								<br /><h3>Admin Main Board</h3><br />
                                
                                <div class="errmsg">  </div>
                                
								<div>
								<form>
                                    <label for="txtPatientID">Patient Name </label>
                                    <input type='text' id="txtPatientID" value="" onKeyUp="getPatientFromName(this.value)" />
                                    <div id="divPatient">&nbsp;</div>
                                    <input type="button" value="Discharge patient" onclick="discharge_booking()" />
                                </div>
                                <div class="report">
                                
                                </div>
							</div>
						</div>
                                        
					</div>
				</div>
			</div>
			<?php include "ext/footer.php" ; ?>
		</div>
	</div>
</body>
</html>