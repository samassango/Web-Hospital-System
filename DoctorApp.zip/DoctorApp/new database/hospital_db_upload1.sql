-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 27, 2015 at 01:20 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hospital_db_upload`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins_tb`
--

CREATE TABLE IF NOT EXISTS `admins_tb` (
  `idnos` varchar(13) NOT NULL,
  `names` varchar(25) NOT NULL,
  `emails` varchar(54) NOT NULL,
  `cells` varchar(12) NOT NULL,
  `hospitals` varchar(25) NOT NULL,
  `adcodes` varchar(13) NOT NULL,
  PRIMARY KEY (`idnos`),
  KEY `surnames` (`emails`,`cells`,`adcodes`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins_tb`
--

INSERT INTO `admins_tb` (`idnos`, `names`, `emails`, `cells`, `hospitals`, `adcodes`) VALUES
('9305245799089', 'Moloko', 'mokolo@kalafong.co.za', '0833532301', 'Kalafong', '90846hh');

-- --------------------------------------------------------

--
-- Table structure for table `book_patients_tb`
--

CREATE TABLE IF NOT EXISTS `book_patients_tb` (
  `bp_code` varchar(13) NOT NULL,
  `p_id` varchar(13) NOT NULL,
  `d_id` varchar(13) NOT NULL,
  `h_id` varchar(15) NOT NULL,
  `fac_code` varchar(16) NOT NULL,
  `date_booked` datetime NOT NULL,
  `descptive_illness` varchar(255) NOT NULL,
  `type_of_treatment` varchar(255) NOT NULL,
  `reliv_date` datetime NOT NULL,
  `record_status` varchar(35) NOT NULL,
  `request_status` varchar(14) NOT NULL,
  KEY `record_status` (`record_status`),
  KEY `h_id` (`h_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_patients_tb`
--

INSERT INTO `book_patients_tb` (`bp_code`, `p_id`, `d_id`, `h_id`, `fac_code`, `date_booked`, `descptive_illness`, `type_of_treatment`, `reliv_date`, `record_status`, `request_status`) VALUES
('BKN0000014', '9002035609087', '9009205853080', 'HSO-0000008', '', '2015-06-06 12:24:46', 'Heart Disease', 'Public', '2015-07-27 08:47:35', 'discharged', 'Approved'),
('BKN0000015', '9002035609087', '9009205853080', 'HSO-0000001', '1', '2015-06-23 08:41:47', 'Heart Disease', 'Public', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000003', '9002035609087', '9009205853080', 'HSO-0000001', '', '2015-07-25 20:30:46', 'Heart Disease', 'Public', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000004', '9002035609087', '9009205853080', 'HSO-0000001', '1', '2015-07-25 20:42:29', 'Heart Disease', 'Public', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000005', '9002035609087', '9009205853080', 'HSO-0000001', '', '2015-07-25 20:44:08', 'Heart Disease', 'Public', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000006', '9002035609087', '9009205853080', 'HSO-0000001', '', '2015-07-25 21:07:21', 'not set', 'not set', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000007', '9002035609087', '9009205853080', 'HSO-0000001', '', '2015-07-25 21:08:08', 'not set', 'not set', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000008', '9009205853080', '9009205853080', 'HSO-0000002', '28', '2015-07-25 21:14:26', 'not set', 'not set', '2015-07-27 10:19:28', 'discharged', 'Pending'),
('BKN0000009', '9002035609087', '9009205853080', 'HSO-0000001', '', '2015-07-25 21:42:38', 'not set', 'not set', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN00000010', '9002035609087', '9009205853080', 'HSO-0000001', '', '2015-07-25 21:43:10', 'not set', 'not set', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000011', '9002035609087', '9009205853080', 'HSO-0000001', '', '2015-07-25 21:45:14', 'not set', 'not set', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000012', '9009205853080', '9009205853080', 'HSO-0000001', '', '2015-07-25 21:51:25', 'not set', 'not set', '2015-07-27 10:19:28', 'discharged', 'Pending'),
('BKN0000013', '9002035609087', '9009205853080', 'HSO-0000001', '', '2015-07-25 21:55:35', 'not set', 'not set', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000014', '9002035609087', '9009205853080', 'HSO-0000001', '', '2015-07-25 21:58:32', 'not set', 'not set', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000015', '9002035609087', '9009205853080', 'HSO-0000001', '', '2015-07-25 22:01:04', 'not set', 'not set', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000016', '9002035609087', '9009205853080', 'HSO-0000001', '', '2015-07-25 22:03:09', 'Heart Disease', 'Public', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000017', '9002035609087', '9009205853080', 'HSO-0000002', '', '2015-07-25 22:32:49', 'Heart Disease', 'Public', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000018', '9002035609087', '9009205853080', 'HSO-0000001', '', '2015-07-25 23:11:08', 'Heart Disease', 'Public', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000019', '9009205853080', '9009205853080', 'HSO-0000001', '', '2015-07-25 23:11:29', 'Heart Disease', 'Public', '2015-07-27 10:19:28', 'discharged', 'Pending'),
('BKN0000020', '9002035609087', '9009205853080', 'HSO-0000003', '', '2015-07-25 23:13:17', 'Heart Disease', 'Public', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000021', '9002035609087', '9009205853080', 'HSO-0000002', '', '2015-07-25 23:13:39', 'Heart Disease', 'Public', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000022', '9009205853080', '9009205853080', 'HSO-0000001', '', '2015-07-25 23:14:24', 'Heart Disease', 'Public', '2015-07-27 10:19:28', 'discharged', 'Pending'),
('BKN0000023', '9009205853080', '9009205853080', 'HSO-0000001', '', '2015-07-26 14:12:59', 'Heart Disease', 'Public', '2015-07-27 10:19:28', 'discharged', 'Pending'),
('BKN0000024', '9002035609087', '9009205853080', 'HSO-0000001', '', '2015-07-26 14:26:44', 'Heart Disease', 'Public', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000025', '9002035609087', '9009205853080', 'HSO-0000001', '', '2015-07-26 14:29:23', 'Heart Disease', 'Public', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000026', '', '9009205853080', 'HSO-0000001', '', '2015-07-26 14:33:18', 'not set', 'not set', '2015-07-26 14:33:18', 'active', 'Pending'),
('BKN0000027', '9002035609087', '9009205853080', 'HSO-0000001', '', '2015-07-26 14:59:05', 'Heart Disease', 'Public', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000028', '9002035609087', '9009205853080', 'HSO-0000001', '', '2015-07-26 15:05:16', 'Heart Disease', 'Public', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000029', '9002035609087', '9009205853080', 'HSO-0000004', '', '2015-07-26 15:06:10', 'Heart Disease', 'Public', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000030', '9002035609087', '9009205853080', 'HSO-0000001', '', '2015-07-26 15:28:33', 'Heart Disease', 'Public', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000031', '9002035609087', '9009205853080', 'HSO-0000001', '', '2015-07-26 15:30:56', 'Heart Disease', 'Public', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000032', '9002035609087', '9009205853080', 'HSO-0000001', '', '2015-07-26 15:32:15', 'Heart Disease', 'Public', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000033', '9002035609087', '9009205853080', 'HSO-0000001', '', '2015-07-26 15:32:32', 'Heart Disease', 'Public', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000034', '9002035609087', '9009205853080', 'HSO-0000001', '', '2015-07-26 15:33:53', 'Heart Disease', 'Public', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000035', '9002035609087', '9009205853080', 'HSO-0000001', '', '2015-07-26 15:34:19', 'Heart Disease', 'Public', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000036', '9002035609087', '9009205853080', 'HSO-0000001', '', '2015-07-26 15:41:15', 'Heart Disease', 'Public', '2015-07-27 08:47:35', 'discharged', 'Pending'),
('BKN0000037', '9002035609087', '9009205853080', 'HSO-0000001', '1', '2015-07-27 09:20:35', 'Heart Disease', 'Public', '2015-07-27 09:20:35', 'active', 'Pending'),
('BKN0000038', '9009205853080', '9009205853080', 'HSO-0000001', '1', '2015-07-27 09:32:18', 'Heart Disease', 'Public', '2015-07-27 10:19:28', 'discharged', 'Pending'),
('BKN0000039', '9002035609087', '9009205853080', 'HSO-0000001', '1', '2015-07-27 09:33:09', 'Heart Disease', 'Public', '2015-07-27 09:33:09', 'active', 'Pending'),
('BKN0000040', '9002035609087', '9009205853080', 'HSO-0000001', '1', '2015-07-27 09:37:16', 'Heart Disease', 'Public', '2015-07-27 09:37:16', 'active', 'Pending'),
('BKN0000041', '9002035609087', '9009205853080', 'HSO-0000002', '28', '2015-07-27 09:44:39', 'Heart Disease', 'Public', '2015-07-27 09:44:39', 'active', 'Pending'),
('BKN0000042', '9009205853080', '9009205853080', 'HSO-0000002', '28', '2015-07-27 09:47:40', 'Heart Disease', 'Public', '2015-07-27 10:19:28', 'discharged', 'Pending'),
('BKN0000043', '9002035609087', '9009205853080', 'HSO-0000001', '1', '2015-07-27 09:48:47', 'Heart Disease', 'Public', '2015-07-27 09:48:47', 'active', 'Pending'),
('BKN0000044', '9002035609087', '9009205853080', 'HSO-0000001', '1', '2015-07-27 09:53:23', 'Heart Disease', 'Public', '2015-07-27 09:53:23', 'active', 'Pending'),
('BKN0000045', '9002035609087', '9009205853080', 'HSO-0000002', '28', '2015-07-27 09:54:03', 'Heart Disease', 'Public', '2015-07-27 09:54:03', 'active', 'Pending'),
('BKN0000046', '9009205853080', '9009205853080', 'HSO-0000002', '28', '2015-07-27 09:56:05', 'Heart Disease', 'Public', '2015-07-27 10:19:28', 'discharged', 'Pending'),
('BKN0000047', '9002035609087', '9009205853080', 'HSO-0000002', '28', '2015-07-27 09:56:20', 'Heart Disease', 'Public', '2015-07-27 09:56:20', 'active', 'Pending'),
('BKN0000048', '9009205853080', '9009205853080', 'HSO-0000002', '28', '2015-07-27 09:57:45', 'Heart Disease', 'Public', '2015-07-27 10:19:28', 'discharged', 'Pending'),
('BKN0000049', '9009205853080', '9009205853080', 'HSO-0000002', '28', '2015-07-27 10:03:47', 'Heart Disease', 'Public', '2015-07-27 10:19:28', 'discharged', 'Pending'),
('BKN0000050', '9009205853080', '9009205853080', 'HSO-0000002', '28', '2015-07-27 10:16:11', 'Heart Disease', 'Public', '2015-07-27 10:19:28', 'discharged', 'Pending'),
('BKN0000051', '9009205853080', '9009205853080', 'HSO-0000002', '28', '2015-07-27 11:30:33', 'Heart Disease', 'Public', '2015-07-27 11:30:33', 'active', 'Pending'),
('BKN0000052', '9009205853080', '9009205853080', 'HSO-0000002', '28', '2015-07-27 11:36:25', 'Heart Disease', 'Public', '2015-07-27 11:36:25', 'active', 'Pending'),
('BKN0000053', '9009205853080', '9009205853080', 'HSO-0000002', '28', '2015-07-27 11:39:05', 'Heart Disease', 'Public', '2015-07-27 11:39:05', 'active', 'Pending'),
('BKN0000054', '9002035609087', '9009205853080', 'HSO-0000002', '28', '2015-07-27 11:43:27', 'Heart Disease', 'Public', '2015-07-27 11:43:27', 'active', 'Pending'),
('BKN0000055', '9009205853080', '9009205853080', 'HSO-0000002', '28', '2015-07-27 12:51:22', 'Heart Disease', 'Public', '2015-07-27 12:51:22', 'active', 'Pending'),
('BKN0000056', '9002035609087', '9009205853080', 'HSO-0000002', '28', '2015-07-27 13:01:56', 'Heart Disease', 'Public', '2015-07-27 13:01:56', 'active', 'Pending'),
('BKN0000057', '9002035609087', '9009205853080', 'HSO-0000006', '17', '2015-07-27 13:18:07', 'Heart Disease', 'Public', '2015-07-27 13:18:07', 'active', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `doctors_tb`
--

CREATE TABLE IF NOT EXISTS `doctors_tb` (
  `idnos` varchar(13) NOT NULL,
  `names` varchar(25) NOT NULL,
  `cells` varchar(12) NOT NULL,
  `emails` varchar(45) NOT NULL,
  `hospitals` varchar(45) NOT NULL,
  `locations` varchar(35) NOT NULL,
  `specials` varchar(45) NOT NULL,
  `prnos` varchar(25) NOT NULL,
  PRIMARY KEY (`idnos`),
  KEY `cells` (`cells`),
  KEY `emails` (`emails`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctors_tb`
--

INSERT INTO `doctors_tb` (`idnos`, `names`, `cells`, `emails`, `hospitals`, `locations`, `specials`, `prnos`) VALUES
('9009205853080', 'ndebele', '0727039498', 'chasfiso@gmail.com', 'Johannesburg Hospital', 'Park Town', 'Heart Surgery', '101');

-- --------------------------------------------------------

--
-- Table structure for table `hospital_facilities_tb`
--

CREATE TABLE IF NOT EXISTS `hospital_facilities_tb` (
  `fac_ward_name` varchar(200) NOT NULL,
  `fac_code` varchar(16) NOT NULL,
  `fac_name` varchar(35) NOT NULL,
  `h_code` varchar(15) NOT NULL,
  `fac_no_booked` int(8) NOT NULL,
  `fac_available` int(20) NOT NULL,
  PRIMARY KEY (`fac_code`),
  KEY `fac_name` (`fac_name`),
  KEY `h_code` (`h_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hospital_facilities_tb`
--

INSERT INTO `hospital_facilities_tb` (`fac_ward_name`, `fac_code`, `fac_name`, `h_code`, `fac_no_booked`, `fac_available`) VALUES
('WARD 1', '1', 'Bed', 'HSO-0000001', 20, 0),
('WARD 3', '10', 'Bed', 'HSO-0000003', 1, 19),
('', '11', 'Othorpaedic Operating Theaters', 'HSO-0000003', 0, 0),
('', '12', 'Plastic Surgery Operating Theaters', 'HSO-0000003', 0, 0),
('', '13', 'Dental with maxillofacial Operating', 'HSO-0000003', 0, 0),
('WARD 2', '14', 'Thoracic Operating theater', 'HSO-0000004', 1, 19),
('', '15', 'Neurology Operating Theaters', 'HSO-0000004', 0, 0),
('', '16', 'Psychiatric ward', 'HSO-0000005', 0, 0),
('', '17', 'Psychiatric ward', 'HSO-0000006', 0, 0),
('', '18', 'Psychiatric ward', 'HSO-0000007', 0, 0),
('', '19', 'Psychiatric ward', 'HSO-0000008', 0, 0),
('', '2', 'Cardiac Operating Theaters', 'HSO-0000001', 0, 0),
('', '20', 'Psychiatric ward', 'HSO-0000009', 0, 0),
('', '21', 'Psychiatric ward', 'HSO-0000010', 0, 0),
('', '22', 'Psychiatric ward', 'HSO-0000011', 0, 0),
('', '23', 'Cardiac Operating Theaters', 'HSO-0000005', 0, 0),
('', '24', 'Bed', 'HSO-0000005', 0, 0),
('', '25', 'Bed', 'HSO-0000007', 0, 0),
('WARD 2', '26', 'Bed', 'HSO-0000010', 0, 20),
('WARD 2', '27', 'Bed', 'HSO-0000001', 0, 20),
('WARD 1', '28', 'Bed', 'HSO-0000002', 12, 8),
('', '3', 'Thoracic Operating Theaters', 'HSO-0000001', 0, 0),
('', '4', 'Ophthalmology Operating Theaters', 'HSO-0000001', 0, 0),
('', '5', 'Bed', 'HSO-0000002', 0, 0),
('', '6', 'Neurology Operating Theaters', 'HSO-0000002', 0, 0),
('', '7', 'Obstetric Operating Theaters', 'HSO-0000002', 0, 0),
('', '8', 'Urology Operating Theaters', 'HSO-0000002', 0, 0),
('', '9', 'General Surgery Operating Theaters', 'HSO-0000002', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `hostipals_tb`
--

CREATE TABLE IF NOT EXISTS `hostipals_tb` (
  `h_code` varchar(15) NOT NULL,
  `h_name` varchar(35) NOT NULL,
  `h_address` varchar(155) NOT NULL,
  `h_long` varchar(25) NOT NULL,
  `h_lati` varchar(25) NOT NULL,
  PRIMARY KEY (`h_code`),
  KEY `h_long` (`h_long`,`h_lati`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hostipals_tb`
--

INSERT INTO `hostipals_tb` (`h_code`, `h_name`, `h_address`, `h_long`, `h_lati`) VALUES
('HSO-0000001', 'Akasia Private Hospital', 'Pretoria,South Africa', '55.1880560', '-25.7461110'),
('HSO-0000002', 'Dr George Mukhari Public Hospital', '3111 Setlogelo Street 0002', '28.1863800', '-25.7495700'),
('HSO-0000003', 'Bougainville Private Hospital', '0001 block bb', '28.1538600', '-25.7156260'),
('HSO-0000004', 'Jakaranda Hospital', '213 Middelberg Street', '28.1880560', '-25.7461110'),
('HSO-0000005', 'Heart Hospital', '551 Park Street Arcadia', '28.2069800', '-25.7493400'),
('HSO-0000006', 'Gynaecological Hospital', '132 Celliers Street Sunnyside', '28.2099000', '-25.7495000'),
('HSO-0000007', 'Femina Hospital', '460 Belvedere Street Arcadia', '28.2007330', '-25.7403950'),
('HSO-0000008', 'Faerie Glen Hospital', 'C/o Atterbury & Oberon Avenue', '28.2910240', '-25.7832490'),
('HSO-0000009', 'Eugene Hospital', '696 5th Avenue', '28.1943970', '-25.7096810'),
('HSO-0000010', 'Psychiatric Hospital', '507 Lancelot Rd', '28.1634670', '-25.7630290'),
('HSO-0000011', 'Denmar Hospital', '508 Lancelot Rd Garsfontein', '28.1880560', '-25.7461110'),
('HSO-0000012', 'Brooklyn Day Hospital', '154 Olivier Street', '28.1880560', '-25.7461110');

-- --------------------------------------------------------

--
-- Table structure for table `logins_tb`
--

CREATE TABLE IF NOT EXISTS `logins_tb` (
  `unames` varchar(12) NOT NULL,
  `pwords` varchar(12) NOT NULL,
  `utypes` varchar(15) NOT NULL,
  `idnos` varchar(13) NOT NULL,
  PRIMARY KEY (`unames`),
  KEY `utypes` (`utypes`),
  KEY `idnos` (`idnos`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logins_tb`
--

INSERT INTO `logins_tb` (`unames`, `pwords`, `utypes`, `idnos`) VALUES
('gontsi', 'matsatsi', 'Admin', '9202090908087'),
('sfisoT', 'sfisoT', 'Doctor', '9009205853080');

-- --------------------------------------------------------

--
-- Table structure for table `patients_tb`
--

CREATE TABLE IF NOT EXISTS `patients_tb` (
  `idnos` varchar(13) NOT NULL,
  `names` varchar(25) NOT NULL,
  `surnames` varchar(35) NOT NULL,
  `houses` varchar(25) NOT NULL,
  `streets` varchar(25) NOT NULL,
  `postals` varchar(10) NOT NULL,
  `payments` varchar(25) NOT NULL,
  `medicals` varchar(35) NOT NULL,
  `illnesses` varchar(25) NOT NULL,
  `priorty` int(11) NOT NULL,
  PRIMARY KEY (`idnos`),
  KEY `surnames` (`surnames`,`houses`,`payments`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patients_tb`
--

INSERT INTO `patients_tb` (`idnos`, `names`, `surnames`, `houses`, `streets`, `postals`, `payments`, `medicals`, `illnesses`, `priorty`) VALUES
('9002035609087', 'zizipho', 'dlamini', 'halala', 'halala', '203', 'Cash', 'Public', 'Heart Disease', 9),
('9009205853080', 'zizipho', 'ndebele', 'halala', 'halala', '0472', 'Cash', 'Public', 'Heart Disease', 6);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `hospital_facilities_tb`
--
ALTER TABLE `hospital_facilities_tb`
  ADD CONSTRAINT `hospital_facilities_tb_ibfk_1` FOREIGN KEY (`h_code`) REFERENCES `hostipals_tb` (`h_code`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
