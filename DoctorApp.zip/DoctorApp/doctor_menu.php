<?php
	session_start() ;
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Doctor finder - Doctor Details</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
    <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
</head>
<body>
	<div class="background">
		<div class="page">
        	
			<a href="index.html" id="logo">Doctor finder</a>
			<div class="sidebar">
				<ul>
					<li class="selected">
						<a href="doctor_menu.php">Home</a>
					</li>
					<li>
						<a href="add_patient.php">Add Patient</a>
					</li>
					<li>
						<a href="view_patient_requests.php">View Requests</a>
					</li>
					<li>
						<a href="search_nearest_hospital.php">Search</a>
					</li>
					<li>
						<a href="login.php">Logout</a>
					</li>
				</ul>
			</div>
			<div class="body">
				<div class="home">
					<div>
						<div>
							<div>
								<br /><br /><h3>Doctors Main Board</h3><br /><br /><br />
                                
                                <div class="errmsg">  </div>
                                
								<div>
                                	<h1>Welcome, <br />
                                    	Dr. <?php
											include "post/conn.php" ;
											
											$idno = $_SESSION["idnos"] ; 
											
											$select = "select * from doctors_tb where idnos = '$idno'" ;
											
											$result = $dbconn->query( $select ) ;
											
											$rows = $result->fetch_assoc() ;
											
											$names = $rows["names"] ;
											$hospitals = $rows["hospitals"] ;
											$prnos = $rows["prnos"] ;
											
											echo $names ;
											
											echo " Prc #: " . $prnos ;
											
										?>
                                    </h1>
                                </div>
							</div>
						</div>
                                        
					</div>
				</div>
			</div>
			<?php include "ext/footer.php" ; ?>
		</div>
	</div>
</body>
</html>