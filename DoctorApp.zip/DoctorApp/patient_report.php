<?php
	session_start() ;
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Doctor finder - Patient Report</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
    <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
    <script type="text/javascript" language="javascript" src="js/validation.js"></script>
    <script type="text/javascript" language="javascript">
		function search_booking() {
			
			var name = $("#txtPIDS").val() ;
			var idno = $("#txtPIDT").val() ;
			
			var sear = "" ;
			
			if ( document.getElementById("txtPIDS").selectedIndex > 0 ) sear = name ;
			else sear = idno ;
		
			var str = "search=" + sear ;
			
			$.get( "post/search_my_patients.php?" + str, function(data) {
			   $(".report").html( data ) ;	
			});
		}
		
		function print_search() {
			Popup($(".report").html());
		}
		
		function Popup(data) 
		{
			var dis = new Date().getTime();
			
			var mywindow = window.open('', 'doc#'+dis, 'height=400,width=600');
			mywindow.document.write('<html><head><title>doc#'+dis+'</title>');
			/*optional stylesheet*/ //mywindow.document.write('<link rel="stylesheet" href="main.css" type="text/css" />');
			mywindow.document.write('</head><body >');
			mywindow.document.write(data);
			mywindow.document.write('</body></html>');
	
			mywindow.print();
			mywindow.close();
	
			return true;
		}
    </script>
</head>
<body>
	<div class="background">
		<div class="page">
        	
			<a href="index.html" id="logo">Doctor finder</a>
			<div class="sidebar">
				<ul>
					<li>
						<a href="doctor_menu.php">Home</a>
					</li>
					<li>
						<a href="admit_patient.php">Admit Patient</a>
					</li>
					<li class="selected">
						<a href="patient_report.php">Patient Report</a>
					</li>
					<li>
						<a href="patient.php">New Patient</a>
					</li>
					<li>
						<a href="patient_discharge.php">Discharge</a>
					</li>
					<li>
						<a href="login.php">Logout</a>
					</li>
				</ul>
			</div>
			<div class="body">
				<div class="home">
					<div>
						<div>
							<div>
								<br /><br /><h3>Doctors Main Board</h3><br /><br /><br />
                                
                                <div class="errmsg">  </div>
                                
								<div>
								<form>
                                 	<label for="txtPIDS">Select Patient ID:</label>
                                    <select id="txtPIDS">
                                    	<option>Please select</option>
									<?php
											include "post/conn.php" ;
											
											$idno = $_SESSION["idnos"] ; 
											
											$select = "select * from book_patients_tb where d_id = '$idno'" ;
											
											$result = $dbconn->query( $select ) ;
											
											$rows = $result->fetch_assoc() ;
											
											$p_id = $rows["p_id"] ;
											
											echo "<option value='$p_id'>$p_id</option>" ;
											
										?>
                                        </select>
                                    <label for="txtPIDOR">OR:</label>
                                    <label for="txtPIDT">Type Patient ID:</label>
                                    <input type="text" id="txtPIDT" name="txtPIDT" />
                                    <input type="button" value="Search Patient" onclick="search_booking()" />
                                </div>
                                <div class="report">
                                
                                </div>
							</div>
						</div>
                                        
					</div>
				</div>
			</div>
			<?php include "ext/footer.php" ; ?>
		</div>
	</div>
</body>
</html>