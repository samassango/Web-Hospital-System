<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Doctor finder - Patient Details</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
    <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
    <script type="text/javascript" language="javascript" src="js/validation.js"></script>
    <script type="text/javascript" language="javascript">
		function recovery() {
			var mes = "" ;
			
			var vbol = false ;
			
			 var edtName = $("#edtName").val() ;             
			 var edtSurname = $("#edtSurname").val() ;  
			 var edtIDNO = $("#edtIDNO").val() ;   
			 var edtHouse = $("#edtHouse").val() ;  
			 var edtStreet = $("#edtStreet").val() ; 
			 var edtPostal = $("#edtPostal").val() ; 
			 var edtPayment = $("#edtPayment").val() ; 
			 var edtMedical = $("#edtMedical").val() ; 
			 var edtIllness = $("#edtIllness").val() ; 
			 var edtPriority = $("#edtPriority").val() ;
			 
			if ( string_spaces(edtName) == false || edtName.length < 3 ) {
				mes += "\n > Please provide a valid name." ;
				vbol = true ;
			}
			
			if ( string_spaces(edtSurname) == false || edtSurname.length < 3 ) {
				mes += "\n > Please provide a valid surname." ;
				vbol = true ;
			}
			
			if ( ValidateIDnumber(edtIDNO) == false ) {
				mes += "\n > Please provide a valid RSA ID." ;
				vbol = true ;
			}
			
			if ( string_spaces(edtHouse) == false || edtHouse.length < 3 ) {
				mes += "\n > Please provide a valid house number." ;
				vbol = true ;
			}
			
			if ( string_spaces(edtStreet) == false || edtStreet.length < 3 ) {
				mes += "\n > Please provide a valid street name." ;
				vbol = true ;
			}
			
			if ( all_number(edtPostal) == false || edtPostal.length < 3 ) {
				mes += "\n > Please provide a valid postal." ;
				vbol = true ;
			}
			
			if ( document.getElementById("edtPayment").selectedIndex = 0 ) {
				mes += "\n > Please provide payment method." ;
				vbol = true ;
			}
			
			if ( document.getElementById("edtMedical").selectedIndex = 0 ) {
				mes += "\n > Please provide medical type." ;
				vbol = true ;
			}
			
			if ( string_spaces(edtIllness) == false || edtIllness.length < 3 ) {
				mes += "\n > Please specify the illness." ;
				vbol = true ;
			}
			
			if ( document.getElementById("edtPriority").selectedIndex = 0 ) {
				mes += "\n > Please provide patient priority." ;
				vbol = true ;
			}
			 
			 var str = "name="+edtName+
					   "&surname="+edtSurname+
					   "&idno="+edtIDNO+
					   "&house="+edtHouse+
					   "&street="+edtStreet+
					   "&postal="+edtPostal+
					   "&pay="+edtPayment+
					   "&med="+edtMedical+
					   "&ill="+edtIllness+
					   "&prio="+edtPriority ;
			if ( vbol == false ) {		
				$.get( "post/patient_registration.php?" + str, function(data) {
					alert( data )
					if ( data.substr(0,26) == "Patient successfully added" ) { 

						 $("#edtName").val("") ;             
						 $("#edtSurname").val("") ;  
						 $("#edtIDNO").val("") ;   
						 $("#edtHouse").val("") ;  
						 $("#edtStreet").val("") ; 
						 $("#edtPostal").val("") ; 
						 $("#edtPayment").val("") ; 
						 $("#edtMedical").val("") ; 
						 $("#edtIllness").val("") ; 
						 $("#edtPriority").val("") ;						
					
					}
				});
			} else {
				alert( mes ) ;
			}
		}
    </script>
</head>
<body>
	<div class="background">
		<div class="page">
        	
			<a href="index.html" id="logo">Doctor finder</a>
			<div class="sidebar">
				<ul>
					<li>
						<a href="doctor_menu.php">Home</a>
					</li>
					<li>
						<a href="add_patient.php">Add Patient</a>
					</li>
					<li class="selected">
						<a href="view_patient_requests.php">View Requests</a>
					</li>
					<li>
						<a href="search_nearest_hospital.php">Search</a>
					</li>
					<li>
						<a href="login.php">Logout</a>
					</li>
				</ul>
				<!--<?php include "ext/side.php" ; ?>-->
			</div>
			<div class="body">
				<div class="home">
					<!--<?php include "ext/featured.php" ; ?>-->
					<div>
						<div>
							<!--<?php include "ext/main_details.php" ; ?>-->
							<div>
								<br /><br /><h3>Patient</h3><br /><br /><br />
                                
                                <div class="errmsg">  </div>
                                
								<form>
                                     <label for="edtName">Name</label>
                                     <input type="text" name="edtName" id="edtName" value=""><br />             
                                     <label for="edtSurname">Surname</label>
                                     <input type="text" name="edtSurname" id="edtSurname" value=""><br />  
                                     <label for="edtIDNO">Id NO#</label>
                                     <input type="text" name="edtIDNO" id="edtIDNO" value=""><br />  
                                     <label for="edtHouse">House number</label>
                                     <input type="text" name="edtHouse" id="edtHouse" value=""><br />  
                                     <label for="edtStreet">Street name</label>
                                     <input type="text" name="edtStreet" id="edtStreet" value=""><br /> 
                                     <label for="edtPostal">Postal Code</label>
                                     <input type="text" name="edtPostal" id="edtPostal" value=""><br /> 
                                     <label for="edtPayment">Type Of Payment</label><br />
                                     <select name="edtPayment" id="edtPayment">
                                        <option value="">Please select</option>
                                        <option value="Cash">Cash</option>
                                        <option value="Medical">Medical</option>
                                     </select><br /> 
                                     <label for="edtMedical">Medical Type</label>
                                     <select name="edtMedical" id="edtMedical">
                                        <option value="">Please select</option>
                                        <option value="Public">Public</option>
                                        <option value="Private">Private</option>
                                     </select><br /> 
                                     <label for="edtIllness">Type Of Illness</label>
                                     <textarea name="edtIllness" id="edtIllness" value=""></textarea><br /> 
                                     <label for="edtPriority">Priority</label>
                                     <select name="edtPriority" id="edtPriority">
                                        <option value="">Please select</option>
                                        <?php
                                            for ( $i=1; $i < 11; $i++ )
                                                echo "<option value='$i'>$i</option>" ;
                                        ?>
                                     </select><br /><br /><br />
                                    
                                    <input type="button" value="Register" onclick="recovery()" />
                                </form>
							</div>
						</div>
                        
						<!--<?php include "ext/service.php" ; ?>-->
                                        
					</div>
				</div>
			</div>
			<?php include "ext/footer.php" ; ?>
		</div>
	</div>
</body>
</html>