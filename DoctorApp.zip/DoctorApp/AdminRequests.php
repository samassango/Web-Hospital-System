<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Admin Reports</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
    <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
    <script type="text/javascript" language="javascript" src="js/validation.js"></script>
    <script type="text/javascript" language="javascript">
		function get_patients_booked() {
			location.href = "PatientBooked.php" ;
		}
		
		function get_all_registered_patient() {
			location.href = "PatientList.php" ;
		}
		
		function get_all_registered_doctors() {
			location.href = "DoctorList.php" ;
		}
		
		function Approve(status) {
			$.get( "post/booking_approval.php?status="+status, function(data) {
				if ( data.substr(0,7) == "success" ) {
					alert ( "Request Approved." ) ;
					location.reload() ;
					window.close() ;
				} else {
					alert(data) ;
				}
			});			
		}
    </script>
</head>
<body>
	<div class="background">
		<div class="page">
			<a href="index.html" id="logo">Doctor finder</a>
			<div class="sidebar">
				<ul>
					<li>
						<a href="AdminMain.php">Home</a>
					</li>                    
					<li>
						<a href="AdminReports.php">Reports</a>
					</li>
					<li>
						<a href="patient_discharge.php">Discharge</a>
					</li>
					<li class="selected">
						<a href="AdminRequests.php">Requests</a>
					</li>
					<li>
						<a href="login.php">Logout</a>
					</li>
				</ul>
				<!--<?php include "ext/side.php" ; ?>-->
			</div>
			<div class="body">
				<div class="home">
					<!--<?php include "ext/featured.php" ; ?>-->
					<div>
						<div>
							<!--<?php include "ext/main_details.php" ; ?>-->
							<div>
								<br /><br /><h3>REPORTS</h3><br /><br /><br />
                                
                                <div class="errmsg">  </div>
                                
								<?php
								
									include "post/conn.php" ;
									
									$select = "select * from book_patients_tb" ;
									
									$result = $dbconn->query( $select ) ;
									
									
									if ( $result->num_rows > 0 ) {
										?>
                                        	<table border="1" bordercolor="#333333" cellpadding="5" cellspacing="0" style="font-size: 10px;">
                                            	<tr bgcolor="#333333" style="color:#fff;">
                                                    <th>Patient Name#</th>
                                                    <th>Date Booked</th>
                                                    <th>Patient Illness</th>
                                                    <th>Status</th>
                                                    <th>Action</th>
                                                </tr>
                                        <?php
										
										for ( $i = 0; $i < $result->num_rows; $i++ ) {
											$row = $result->fetch_assoc() ;
											
											$bp_code = $row["bp_code"] ; 
											$p_id = $row["p_id"] ;
											$d_id = $row["d_id"] ;
											$date_booked = $row["date_booked"] ;
											$descptive_illness = $row["descptive_illness"] ;
											$type_of_treatment = $row["type_of_treatment"] ;
											$reliv_date = $row["reliv_date"] ;
											$request_status = $row["request_status"] ;
						
												
												
											$select_patients = "select * from patients_tb where idnos = '$p_id'" ;
											
											$result_patients = $dbconn->query( $select_patients ) ;
											
											if ( $result_patients->num_rows > 0 ) {
												for ( $j = 0; $j < $result_patients->num_rows; $j++ ) {
													$rows_patients = $result_patients->fetch_assoc() ;
													
													$p_id = $rows_patients["names"] . " " .$rows_patients["surnames"] ;
												}
											} else {
												echo "<tr><td colspan='4'>Record moved to history file</td></tr>" ;	
											}
																							
											?>
                                            	<tr bgcolor="#ffffff">
                                                    <td><?php echo $p_id ; ?></td>
                                                    <td><?php echo $date_booked ; ?></td>
                                                    <td><?php echo $descptive_illness ; ?></td>
                                                    <?php if ( $request_status != "" ) { ?>
                                                    <td><?php echo $request_status ; ?></td>
                                                    <?php } else { ?>
                                                    <td><?php echo "Broken status" ; ?></td>
                                                    <?php } ?>
                                                    <?php if ( $request_status == "Pending" ) { ?>
                                                    <td><a href="#" onclick="Approve('<?php echo $bp_code ; ?>')">Approve</a></td>
                                                    <?php } else { ?>
                                                    <td>no action</td>
                                                    <?php } ?>
                                                </tr>                                            	
                                            <?php
	
										}
										echo "</table>" ;
									} else {
									
										echo "<h1>No records found</h1>" ;	
										
									}
									
									
								?>
                                
							</div>
						</div>
                        
						<!--<?php include "ext/service.php" ; ?>-->
                                        
					</div>
				</div>
			</div>
			<?php include "ext/footer.php" ; ?>
		</div>
	</div>
</body>
</html>