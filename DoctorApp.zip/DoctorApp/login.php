<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Doctor finder - Registration</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
    <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
    <script type="text/javascript" language="javascript" src="js/validation.js"></script>
    <script type="text/javascript" language="javascript">
		function login() {
			var uname = $("#txtUsername").val() ;
			var pword = $("#txtPassword").val() ;
		
			var str = "uname=" + uname + "&pword=" + pword ;
			
			$.get( "post/user_login.php?" + str, function(data) {
				if ( data == "Patient" ) {
					//location.href = "Patient.php" ;	
					alert("Good Patient") ;
				} else if ( data.substr(0,6) == "Doctor" ) {
					location.href = "doctor_menu.php" ;
						
				} else if ( data.substr(0,5) == "Admin" ) {
					location.href = "AdminMain.php" ;
				} else {
					alert( data ) ;	
				}
			});
		}
    </script>
</head>
<body>
	<div class="background">
		<div class="page">
			<a href="index.html" id="logo">Doctor finder</a>
			<div class="sidebar">
				<ul>
					<li>
						<a href="index.php">Home</a>
					</li>
					<li>
						<a href="register.php">Register</a>
					</li>
					<li class="selected">
						<a href="login.php">Login</a>
					</li>
				</ul>
				<!--<?php include "ext/side.php" ; ?>-->
			</div>
			<div class="body">
				<div class="home">
					<!--<?php include "ext/featured.php" ; ?>-->
					<div>
						<div>
							<!--<?php include "ext/main_details.php" ; ?>-->
							<div>
								<br /><br /><h3>Please Login</h3><br /><br /><br />
                                
                                <div class="errmsg">  </div>
                                
								<form>
                                	<label for="txtUsername">Username:</label>
                                    <input type="text" id="txtUsername" name="txtUsername" /><br />
                                	<label for="txtPassword">Password:</label>
                                    <input type="password" id="txtPassword" name="txtPassword" /><br /><br /><br />
                                    
                                    <input type="button" value="Register" onclick="location.href='register.php'" />
                                    <input type="button" value="Login" onclick="login()" />
                                    <input type="button" value="Forgot Password" onclick="location.href='forgot_password.php'" />
                                </form>
							</div>
						</div>
                        
						<!--<?php include "ext/service.php" ; ?>-->
                                        
					</div>
				</div>
			</div>
			<?php include "ext/footer.php" ; ?>
		</div>
	</div>
</body>
</html>