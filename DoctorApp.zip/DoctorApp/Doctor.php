<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Doctor finder - Doctor Details</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
    <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
    <script type="text/javascript" language="javascript" src="js/validation.js"></script>
    <script type="text/javascript" language="javascript">
		function recovery() {
			var mes = "" ;
			
			var vbol = false ;
			
			var name = $("#txtName").val() ;
			var idno = $("#txtDoctorID").val() ;
			var email = $("#txtEmail").val() ;
			var prno = $("#txtPracticenumber").val() ;
			var special = $("#txtSpecialization").val() ;
			var cell = $("#txtCellnumber").val() ;
			var hospital = $("#txtPracticehospital").val() ;
			var location = $("#txtSurgerylocation").val() ;
			
			if ( string_spaces(name) == false || name.length < 3 ) {
				mes += "\n > Please provide a valid name." ;
				vbol = true ;
			}
			
			if ( ValidateIDnumber(idno) == false ) {
				mes += "\n > Please provide a valid RSA ID." ;
				vbol = true ;
			}
			
			if ( email_address(email) == false ) {
				mes += "\n > Please provide a valid email." ;
				vbol = true ;
			}
			
			var two = cell.substr(1,2) ;
			
			if ( cell_code(two) == false || cell.length != 10 ) {
				mes += "\n > Please provide a valid cell number." ;
				vbol = true ;				
			}
			
			if ( string_spaces(special) == false || special.length < 3 ) {
				mes += "\n > Please provide a valid specialization." ;
				vbol = true ;
			}
			
			if ( string_spaces(hospital) == false || hospital.length < 3 ) {
				mes += "\n > Please provide a valid hospital name." ;
				vbol = true ;
			}
		
			var str = "name=" + name + 
					  "&idno=" + idno +
					  "&email=" + email +
					  "&prno=" + prno +
					  "&special=" + special +
					  "&cell=" + cell +
					  "&hospital=" + hospital +
					  "&location=" + location ;
			if ( vbol == false ) {
				$.get( "post/doctor_registration.php?" + str, function(data) {
					if ( data.substr(0,7) == "success" ) {
						alert( "Account creation complete." ) ;
						
						$("#txtName").val("") ;
						$("#txtDoctorID").val("") ;
						$("#txtEmail").val("") ;
						$("#txtPracticenumber").val("") ;
						$("#txtSpecialization").val("") ;
						$("#txtCellnumber").val("") ;
						$("#txtPracticehospital").val("") ;
						$("#txtSurgerylocation").val("") ;
						location.href = "index.php" ;		
					} else {
						alert( data ) ;	
					}
					
				});
			
			} else {
				alert( mes ) ;
			}
		}
    </script>
</head>
<body>
	<div class="background">
		<div class="page">
        	
			<a href="index.html" id="logo">Doctor finder</a>
			<div class="sidebar">
				<ul>
					<li>
						<a href="index.php">Home</a>
					</li>
					<li>
						<a href="register.php">Register</a>
					</li>
					<li class="selected">
						<a href="login.php">Login</a>
					</li>
				</ul>
				<!--<?php include "ext/side.php" ; ?>-->
			</div>
			<div class="body">
				<div class="home">
					<!--<?php include "ext/featured.php" ; ?>-->
					<div>
						<div>
							<!--<?php include "ext/main_details.php" ; ?>-->
							<div>
								<br /><br /><h3>Doctor Details</h3><br /><br /><br />
                                
                                <div class="errmsg">  </div>
                                
								<form>
                                	<label for="txtName">Name:</label>
                                    <input type="text" maxlength="25" id="txtName" name="txtName" /><br />
                                	<label for="txtPracticenumber">Practice number:</label>
                                    <input type="text" maxlength="9" id="txtPracticenumber" name="txtPracticenumber" /><br />
                                	<label for="txtPracticehospital">Practice hospital:</label>
                                    <input type="text" id="txtPracticehospital" name="txtPracticehospital" /><br />
                                	<label for="txtEmail">Email:</label>
                                    <input type="text" maxlength="45" id="txtEmail" name="txtEmail" /><br />
                                	<label for="txtCellnumber">Cell number:</label>
                                    <input type="text" id="txtCellnumber" name="txtCellnumber" /><br />
                                	<label for="txtDoctorID">Doctor ID:</label>
                                    <input type="text" maxlength="13" id="txtDoctorID" name="txtDoctorID" /><br />
                                	<label for="txtSurgerylocation">Surgery location:</label>
                                    <input type="text" maxlength="25" id="txtSurgerylocation" name="txtSurgerylocation" /><br />
                                	<label for="txtSpecialization">Specialization:</label>
                                    <input type="text" maxlength="25" id="txtSpecialization" name="txtSpecialization" /><br /><br /><br />
                                    
                                    <input type="button" value="Register" onclick="recovery()" />
                                </form>
							</div>
						</div>
                        
						<!--<?php include "ext/service.php" ; ?>-->
                                        
					</div>
				</div>
			</div>
			<?php include "ext/footer.php" ; ?>
		</div>
	</div>
</body>
</html>