<?php
	session_start() ;
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Doctor finder - Doctor Details</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
    <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
    <script type="text/javascript" language="javascript" src="js/validation.js"></script>
    <script type="text/javascript" language="javascript">
		function record_booking() {
			
			var pid = $("#txtPID").val() ;
			var fid = $("#txtFID").val() ;
			var td = $("#txtTD").val() ;
			var days = $("#txtDays").val() ;
		
			var str = "pid=" + pid + 
					  "&fid=" + fid +
					  "&td=" + td +
					  "&days=" + days ;
			
			$.get( "post/booking_registration.php?" + str, function(data) {
				if ( data == "success" ) {
					$("#txtName").val("") ;
					$("#txtIDNO").val("") ;
					$("#txtEmail").val("") ;
					document.getElementById("txtDays").selectedIndex = 0;
					location.href = "doctor_menu.php" ;		
				} else {
					alert( data ) ;	
				}
			});
		}
    </script>
</head>
<body>
	<div class="background">
		<div class="page">
        	
			<a href="index.html" id="logo">Doctor finder</a>
			<div class="sidebar">
				<ul>
					<li>
						<a href="doctor_menu.php">Home</a>
					</li>
					<li class="selected">
						<a href="admit_patient.php">Admit Patient</a>
					</li>
					<li>
						<a href="patient_report.php">Patient Report</a>
					</li>
					<li>
						<a href="patient.php">New Patient</a>
					</li>
					<li>
						<a href="patient_discharge.php">Discharge</a>
					</li>
					<li>
						<a href="login.php">Logout</a>
					</li>
				</ul>
			</div>
			<div class="body">
				<div class="home">
					<div>
						<div>
							<div>
								<br /><br /><h3>Doctors Main Board</h3><br /><br /><br />
                                
                                <div class="errmsg">  </div>
                                
								<form>
                                 	<label for="txtPID">Patient ID:</label>
                                    <input type="text" id="txtPID" name="txtPID" /><br />
                                 	<label for="txtFID">Full Illness Description:</label>
                                    <textarea id="txtFID" name="txtFID" rows="5" ></textarea><br />   
                                 	<label for="txtTD">Treatment Description:</label>
                                    <textarea id="txtTD" name="txtTD" rows="5" ></textarea><br /><br />  
                                    <label for="txtPID">Number of days in hospital:</label>
                                    <select id="txtDays">
                                    	<option>Please select</option>
                                        <?php
											for( $i=1; $i<32; $i++) echo "<option value='$i'>$i day(s)</option>"
										?>
                                    </select> 
                                    <input type="button" value="Record booking" onclick="record_booking()" />                           	
                                </form>
							</div>
						</div>
                                        
					</div>
				</div>
			</div>
			<?php include "ext/footer.php" ; ?>
		</div>
	</div>
</body>
</html>