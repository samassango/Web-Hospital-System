<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Doctor finder</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
</head>
<body>
	<div class="background">
		<div class="page">
			<a href="index.html" id="logo">Doctor finder</a>
			<div class="sidebar">
				<ul>
					<li class="selected">
						<a href="AdminMain.php">Home</a>
					</li>                    
					<li>
						<a href="AdminReports.php">Reports</a>
					</li>
					<li>
						<a href="patient_discharge.php">Discharge</a>
					</li>
					<li>
						<a href="AdminRequests.php">Requests</a>
					</li>
					<li>
						<a href="login.php">Logout</a>
					</li>
				</ul>
				<?php include "ext/side.php" ; ?>
			</div>
			<div class="body">
				<div class="home">
					<?php include "ext/featured.php" ; ?>
					<div>
						<div>
							<?php include "ext/main_details.php" ; ?>
							<div>
								<h4>Therapy</h4>
								<p>
The use of art helps people to express themselves. Doctor finder’s use of Art Therapy in South Africa is hugely successful because it overcomes language and cultural barriers and is a highly effective way of engaging those affected by traumatic experience. In a country where counselling resource and skills are scarce, the use of Art Therapy accommodates large numbers of people and is cheap to implement.
                                </p>
								<span><a href="programs.html">Learn More</a></span>
							</div>
						</div>
                        
						<?php include "ext/service.php" ; ?>
                                        
					</div>
				</div>
			</div>
			<?php include "ext/footer.php" ; ?>
		</div>
	</div>
</body>
</html>